'use client'

import Link from 'next/link'
import { BookOpen, MessageCircle, Scale, Bot, Library, Users, Sparkles, HelpCircle, User } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { BottomNav } from '@/components/bottom-nav'
import { PageHeader } from '@/components/page-header'

const features = [
  {
    href: '/quran',
    icon: BookOpen,
    title: 'قورئانی پیرۆز',
    description: 'خوێندنەوەی ١١٤ سورە',
    color: 'from-emerald-500 to-green-600',
  },
  {
    href: '/ask',
    icon: MessageCircle,
    title: 'پرسیار و وەڵام',
    description: 'پرسیارەکانت بکە',
    color: 'from-blue-500 to-cyan-600',
  },
  {
    href: '/ai-assistant',
    icon: Bot,
    title: 'یاریدەدەری AI',
    description: 'چاتبۆتی زیرەک',
    color: 'from-purple-500 to-violet-600',
  },
  {
    href: '/hadith',
    icon: Library,
    title: 'فەرمودەکان',
    description: '+١٠٠٠ فەرمودەی صەحیح',
    color: 'from-amber-500 to-orange-600',
  },
  {
    href: '/biography',
    icon: User,
    title: 'ژیاننامەی پێغەمبەر',
    description: 'مێژووی پێغەمبەر ﷺ',
    color: 'from-teal-500 to-emerald-600',
  },
  {
    href: '/inheritance',
    icon: Scale,
    title: 'میراث',
    description: 'ژمێرکاری میراث',
    color: 'from-rose-500 to-pink-600',
  },
  {
    href: '/quiz',
    icon: HelpCircle,
    title: 'تاقیکردنەوە',
    description: 'پرسیارە ڕەندۆمەکان',
    color: 'from-indigo-500 to-blue-600',
  },
  {
    href: '/fatwa',
    icon: Sparkles,
    title: 'فەتوا',
    description: 'حوکمە شەرعییەکان',
    color: 'from-yellow-500 to-amber-600',
  },
]

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background pb-24">
      <PageHeader 
        title="یاریدەدەری ئیسلامی" 
        subtitle="ڕێنمایی دینی و ئیسلامی" 
      />
      
      <main className="px-4 py-6">
        {/* Welcome Card */}
        <Card className="mb-6 overflow-hidden border-0 bg-gradient-to-br from-primary/90 to-primary shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary-foreground/20">
                <Sparkles className="h-7 w-7 text-primary-foreground" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-primary-foreground">
                  بەخێربێیت
                </h2>
                <p className="text-sm text-primary-foreground/80">
                  زانیاری دینی و ئیسلامی لە دەستی تۆدایە
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Features Grid */}
        <div className="grid grid-cols-2 gap-3">
          {features.map((feature) => {
            const Icon = feature.icon
            return (
              <Link key={feature.href} href={feature.href}>
                <Card className="group h-full border-0 bg-card shadow-sm transition-all duration-300 hover:shadow-md hover:-translate-y-0.5">
                  <CardContent className="p-4">
                    <div className={`mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br ${feature.color}`}>
                      <Icon className="h-6 w-6 text-white" />
                    </div>
                    <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors">
                      {feature.title}
                    </h3>
                    <p className="mt-1 text-xs text-muted-foreground">
                      {feature.description}
                    </p>
                  </CardContent>
                </Card>
              </Link>
            )
          })}
        </div>

        {/* Daily Verse Card */}
        <Card className="mt-6 border-0 bg-secondary/50 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-3">
              <BookOpen className="h-5 w-5 text-primary" />
              <h3 className="font-semibold text-foreground">ئایەتی ڕۆژانە</h3>
            </div>
            <p className="text-lg leading-relaxed text-foreground mb-2" dir="rtl">
              بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ
            </p>
            <p className="text-sm text-muted-foreground">
              بەناوی خوای بەخشندە و میهرەبان
            </p>
          </CardContent>
        </Card>
      </main>

      <BottomNav />
    </div>
  )
}
