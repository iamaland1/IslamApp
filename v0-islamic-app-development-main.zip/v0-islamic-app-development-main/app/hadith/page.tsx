'use client'

import { useState, useMemo } from 'react'
import { Search, BookOpen, Filter, Share2, Heart, ChevronDown } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { BottomNav } from '@/components/bottom-nav'
import { PageHeader } from '@/components/page-header'
import { getAllHadiths, categories } from '@/lib/hadith-data'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { toast } from 'sonner'

export default function HadithPage() {
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)
  const [favorites, setFavorites] = useState<number[]>([])
  const [visibleCount, setVisibleCount] = useState(20)

  const allHadiths = useMemo(() => getAllHadiths(), [])

  const filteredHadiths = useMemo(() => {
    return allHadiths.filter((hadith) => {
      const matchesSearch =
        hadith.arabic.includes(searchQuery) ||
        hadith.kurdish.includes(searchQuery) ||
        hadith.narrator.includes(searchQuery)
      const matchesCategory =
        !selectedCategory || hadith.category === selectedCategory
      return matchesSearch && matchesCategory
    })
  }, [allHadiths, searchQuery, selectedCategory])

  const visibleHadiths = filteredHadiths.slice(0, visibleCount)

  const toggleFavorite = (id: number) => {
    setFavorites((prev) =>
      prev.includes(id) ? prev.filter((f) => f !== id) : [...prev, id]
    )
  }

  const shareHadith = (hadith: typeof allHadiths[0]) => {
    const text = `${hadith.arabic}\n\n${hadith.kurdish}\n\n- ${hadith.narrator} (${hadith.source})`
    if (navigator.share) {
      navigator.share({ text })
    } else {
      navigator.clipboard.writeText(text)
      toast.success('فەرمودەکە کۆپی کرا')
    }
  }

  const getCategoryName = (categoryId: string) => {
    return categories.find((c) => c.id === categoryId)?.name || categoryId
  }

  const getCategoryIcon = (categoryId: string) => {
    return categories.find((c) => c.id === categoryId)?.icon || '📖'
  }

  return (
    <div className="min-h-screen bg-background pb-24">
      <PageHeader
        title="فەرمودەکان"
        subtitle={`${allHadiths.length}+ فەرمودەی صەحیح`}
      />

      <main className="px-4 py-4">
        {/* Search and Filter */}
        <div className="flex gap-2 mb-4">
          <div className="relative flex-1">
            <Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="گەڕان..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pr-10 bg-card border-border"
            />
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="icon">
                <Filter className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuItem onClick={() => setSelectedCategory(null)}>
                <span className="ml-2">📚</span>
                هەموو
              </DropdownMenuItem>
              {categories.map((category) => (
                <DropdownMenuItem
                  key={category.id}
                  onClick={() => setSelectedCategory(category.id)}
                >
                  <span className="ml-2">{category.icon}</span>
                  {category.name}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* Categories */}
        <div className="flex gap-2 overflow-x-auto pb-4 mb-4 scrollbar-hide">
          <Button
            variant={selectedCategory === null ? 'default' : 'outline'}
            size="sm"
            onClick={() => setSelectedCategory(null)}
            className="shrink-0"
          >
            هەموو
          </Button>
          {categories.map((category) => (
            <Button
              key={category.id}
              variant={selectedCategory === category.id ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedCategory(category.id)}
              className="shrink-0 gap-1"
            >
              <span>{category.icon}</span>
              {category.name}
            </Button>
          ))}
        </div>

        {/* Stats */}
        <div className="flex items-center justify-between mb-4">
          <p className="text-sm text-muted-foreground">
            {filteredHadiths.length} فەرمودە
          </p>
          {selectedCategory && (
            <Badge variant="secondary" className="gap-1">
              {getCategoryIcon(selectedCategory)}
              {getCategoryName(selectedCategory)}
            </Badge>
          )}
        </div>

        {/* Hadith List */}
        <div className="space-y-3">
          {visibleHadiths.map((hadith) => (
            <Card
              key={hadith.id}
              className="border-0 bg-card shadow-sm overflow-hidden"
            >
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-2 mb-3">
                  <Badge
                    variant="secondary"
                    className={`shrink-0 ${
                      hadith.grade === 'صەحیح'
                        ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400'
                        : hadith.grade === 'حەسەن'
                        ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400'
                        : 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400'
                    }`}
                  >
                    {hadith.grade}
                  </Badge>
                  <Badge variant="outline" className="shrink-0 gap-1">
                    {getCategoryIcon(hadith.category)}
                    {getCategoryName(hadith.category)}
                  </Badge>
                </div>

                {/* Arabic Text */}
                <p
                  className="text-lg leading-loose text-foreground mb-3 font-semibold"
                  dir="rtl"
                >
                  {hadith.arabic}
                </p>

                {/* Kurdish Translation */}
                <p className="text-muted-foreground leading-relaxed mb-4">
                  {hadith.kurdish}
                </p>

                {/* Source */}
                <div className="flex items-center justify-between border-t pt-3">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <BookOpen className="h-4 w-4" />
                    <span>{hadith.narrator}</span>
                    <span className="text-border">|</span>
                    <span>{hadith.source}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => toggleFavorite(hadith.id)}
                    >
                      <Heart
                        className={`h-4 w-4 ${
                          favorites.includes(hadith.id)
                            ? 'fill-red-500 text-red-500'
                            : ''
                        }`}
                      />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => shareHadith(hadith)}
                    >
                      <Share2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Load More */}
        {visibleCount < filteredHadiths.length && (
          <Button
            variant="outline"
            className="w-full mt-4 gap-2"
            onClick={() => setVisibleCount((prev) => prev + 20)}
          >
            <ChevronDown className="h-4 w-4" />
            زیاتر ببینە ({filteredHadiths.length - visibleCount} ماوە)
          </Button>
        )}

        {filteredHadiths.length === 0 && (
          <div className="text-center py-12">
            <BookOpen className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <p className="text-muted-foreground">هیچ فەرمودەیەک نەدۆزرایەوە</p>
          </div>
        )}
      </main>

      <BottomNav />
    </div>
  )
}
