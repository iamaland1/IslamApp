'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { 
  BookOpen, 
  MessageSquare, 
  ScrollText, 
  User, 
  HelpCircle,
  Heart,
  Star,
  Code,
  Globe,
  Mail,
  ExternalLink
} from 'lucide-react'
import Link from 'next/link'
import PageHeader from '@/components/page-header'

const features = [
  {
    icon: BookOpen,
    title: 'قورئانی پیرۆز',
    description: '١١٤ سورەت بە وەرگێڕانی کوردی'
  },
  {
    icon: ScrollText,
    title: 'حەدیسی نەبەوی',
    description: 'زیاتر لە ١٠٠٠ فەرموودەی پێغەمبەر ﷺ'
  },
  {
    icon: User,
    title: 'ژیاننامەی پێغەمبەر ﷺ',
    description: 'ژیان و کاتنامەی پیرۆز'
  },
  {
    icon: MessageSquare,
    title: 'یاریدەدەری زیرەکی دەستکرد',
    description: 'وەڵامدانەوەی پرسیارەکانت'
  },
  {
    icon: HelpCircle,
    title: 'یاری پرسیار و وەڵام',
    description: 'تاقیکردنەوەی زانیاریەکانت'
  }
]

const team = [
  { name: 'پشتیوان بەکر', role: 'گەشەپێدەر' },
]

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-background pb-24">
      <PageHeader 
        title="دەربارەی بەرنامەکە"
        subtitle="بەرنامەی ئیسلامی بە کوردی"
      />

      <main className="container mx-auto px-4 py-6 space-y-6">
        {/* App Info */}
        <Card className="bg-gradient-to-br from-primary/5 to-accent/5 border-primary/20 overflow-hidden relative">
          <div className="absolute top-0 left-0 w-full h-full opacity-5">
            <div className="absolute top-4 left-4 text-8xl font-serif">بسم الله</div>
          </div>
          <CardContent className="pt-6 relative">
            <div className="text-center space-y-4">
              <div className="w-20 h-20 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto">
                <Star className="h-10 w-10 text-primary" />
              </div>
              <div>
                <h2 className="text-2xl font-bold">بەرنامەی ئیسلامی</h2>
                <p className="text-muted-foreground">نۆری ژیانت</p>
              </div>
              <div className="flex items-center justify-center gap-2">
                <Badge variant="outline">وەشانی ١.٠.٠</Badge>
                <Badge className="bg-primary">بەتا</Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Mission */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Heart className="h-5 w-5 text-primary" />
              مەبەستمان
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground leading-loose">
              مەبەستی ئەم بەرنامەیە ئەوەیە کە زانیارییەکانی ئیسلامی بە زمانی کوردی بخاتە بەردەست خەڵکی کورد. 
              ئێمە باوەڕمان بەوەیە کە هەموو کەسێک مافی ئەوەی هەیە بە زمانی خۆی فێری ئایینەکەی ببێت.
              ئەم بەرنامەیە تایبەتمەندییەکی زۆری تێدایە وەک قورئان، حەدیس، ژیاننامەی پێغەمبەر ﷺ، 
              و یاریدەدەری زیرەکی دەستکرد بۆ وەڵامدانەوەی پرسیارەکانت.
            </p>
          </CardContent>
        </Card>

        {/* Features */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Globe className="h-5 w-5 text-primary" />
              تایبەتمەندییەکان
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {features.map((feature, idx) => (
              <div key={idx} className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                  <feature.icon className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium">{feature.title}</h3>
                  <p className="text-sm text-muted-foreground">{feature.description}</p>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Team */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Code className="h-5 w-5 text-primary" />
              تیمی گەشەپێدان
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {team.map((member, idx) => (
                <div key={idx} className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <User className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium">{member.name}</p>
                    <p className="text-sm text-muted-foreground">{member.role}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Contact */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Mail className="h-5 w-5 text-primary" />
              پەیوەندی
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-muted-foreground">
              بۆ پێشنیار، ڕەخنە، یان هەر پرسیارێک پەیوەندیمان پێوە بکەن:
            </p>
            <Button variant="outline" className="w-full" asChild>
              <a href="mailto:contact@islamicapp.krd">
                <Mail className="h-4 w-4 ml-2" />
                contact@islamicapp.krd
              </a>
            </Button>
          </CardContent>
        </Card>

        {/* Acknowledgments */}
        <Card>
          <CardHeader>
            <CardTitle>سوپاسگوزاری</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground leading-loose">
              سوپاس بۆ خودای گەورە کە یارمەتیمانی دا لە دروستکردنی ئەم بەرنامەیەدا.
              هەروەها سوپاس بۆ هەموو ئەو کەسانەی کە هاوکاریمان کرد لە وەرگێڕان و پشکنیندا.
            </p>
          </CardContent>
        </Card>

        {/* Version Info */}
        <Card className="bg-muted/50">
          <CardContent className="pt-6">
            <div className="text-center text-sm text-muted-foreground space-y-2">
              <p>وەشانی ١.٠.٠ - بەتا</p>
              <p>دروستکراوە بە خۆشەویستی بۆ کوردستان</p>
              <Separator className="my-4" />
              <p className="text-xs">
                هەموو مافەکان پارێزراون © ٢٠٢٤
              </p>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
