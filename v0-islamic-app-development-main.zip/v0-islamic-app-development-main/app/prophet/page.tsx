'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Button } from '@/components/ui/button'
import { 
  prophetTimeline, 
  prophetSections, 
  prophetQualities,
  getCategoryLabel,
  getCategoryColor
} from '@/lib/prophet-data'
import { Calendar, BookOpen, Star, ChevronLeft, ChevronRight, Heart } from 'lucide-react'
import Link from 'next/link'
import PageHeader from '@/components/page-header'

type FilterCategory = 'all' | 'birth' | 'revelation' | 'migration' | 'battle' | 'treaty' | 'conquest' | 'death' | 'other'

export default function ProphetPage() {
  const [selectedCategory, setSelectedCategory] = useState<FilterCategory>('all')
  const [selectedSection, setSelectedSection] = useState<string | null>(null)

  const filteredTimeline = selectedCategory === 'all' 
    ? prophetTimeline 
    : prophetTimeline.filter(event => event.category === selectedCategory)

  const categories: FilterCategory[] = ['all', 'birth', 'revelation', 'migration', 'battle', 'treaty', 'conquest', 'death', 'other']

  const getCategoryName = (cat: FilterCategory): string => {
    if (cat === 'all') return 'هەموو'
    return getCategoryLabel(cat)
  }

  return (
    <div className="min-h-screen bg-background pb-24">
      <PageHeader 
        title="ژیاننامەی پێغەمبەر ﷺ"
        subtitle="محمد بن عەبدوڵا"
      />

      <main className="container mx-auto px-4 py-6">
        <Tabs defaultValue="timeline" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="timeline" className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              <span>کاتنامە</span>
            </TabsTrigger>
            <TabsTrigger value="biography" className="flex items-center gap-2">
              <BookOpen className="h-4 w-4" />
              <span>ژیاننامە</span>
            </TabsTrigger>
            <TabsTrigger value="qualities" className="flex items-center gap-2">
              <Star className="h-4 w-4" />
              <span>ڕەوشتەکان</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="timeline" className="space-y-4">
            {/* Category Filter */}
            <ScrollArea className="w-full whitespace-nowrap">
              <div className="flex gap-2 pb-2">
                {categories.map(cat => (
                  <Button
                    key={cat}
                    variant={selectedCategory === cat ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setSelectedCategory(cat)}
                    className="shrink-0"
                  >
                    {getCategoryName(cat)}
                  </Button>
                ))}
              </div>
            </ScrollArea>

            {/* Timeline */}
            <div className="relative">
              {/* Timeline line */}
              <div className="absolute right-4 top-0 bottom-0 w-0.5 bg-primary/20" />

              <div className="space-y-4">
                {filteredTimeline.map((event, index) => (
                  <div key={event.id} className="relative flex gap-4 pr-8">
                    {/* Timeline dot */}
                    <div className="absolute right-2 top-6 w-4 h-4 rounded-full bg-primary border-4 border-background z-10" />

                    <Card className="flex-1 transition-all hover:shadow-md">
                      <CardHeader className="pb-2">
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex items-center gap-2">
                            <span className="text-lg font-bold text-primary font-mono">{event.year}</span>
                            <Badge className={getCategoryColor(event.category)}>
                              {getCategoryLabel(event.category)}
                            </Badge>
                          </div>
                        </div>
                        <CardTitle className="text-lg leading-relaxed">{event.title}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-muted-foreground leading-relaxed">{event.description}</p>
                      </CardContent>
                    </Card>
                  </div>
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="biography" className="space-y-4">
            {selectedSection ? (
              <div className="space-y-4">
                <Button 
                  variant="ghost" 
                  onClick={() => setSelectedSection(null)}
                  className="flex items-center gap-2"
                >
                  <ChevronRight className="h-4 w-4" />
                  گەڕانەوە بۆ لیست
                </Button>

                {(() => {
                  const section = prophetSections.find(s => s.id === selectedSection)
                  if (!section) return null
                  
                  const currentIndex = prophetSections.findIndex(s => s.id === selectedSection)
                  const prevSection = currentIndex > 0 ? prophetSections[currentIndex - 1] : null
                  const nextSection = currentIndex < prophetSections.length - 1 ? prophetSections[currentIndex + 1] : null

                  return (
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-2xl">{section.title}</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        {section.content.split('\n\n').map((paragraph, idx) => (
                          <p key={idx} className="text-foreground leading-loose text-lg">
                            {paragraph}
                          </p>
                        ))}

                        <div className="flex justify-between pt-6 border-t">
                          {prevSection ? (
                            <Button 
                              variant="outline" 
                              onClick={() => setSelectedSection(prevSection.id)}
                              className="flex items-center gap-2"
                            >
                              <ChevronRight className="h-4 w-4" />
                              {prevSection.title}
                            </Button>
                          ) : <div />}
                          
                          {nextSection && (
                            <Button 
                              variant="outline" 
                              onClick={() => setSelectedSection(nextSection.id)}
                              className="flex items-center gap-2"
                            >
                              {nextSection.title}
                              <ChevronLeft className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  )
                })()}
              </div>
            ) : (
              <div className="grid gap-4">
                {prophetSections.map((section, index) => (
                  <Card 
                    key={section.id}
                    className="cursor-pointer transition-all hover:shadow-md hover:border-primary/50"
                    onClick={() => setSelectedSection(section.id)}
                  >
                    <CardHeader className="pb-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">
                            {index + 1}
                          </div>
                          <CardTitle className="text-xl">{section.title}</CardTitle>
                        </div>
                        <ChevronLeft className="h-5 w-5 text-muted-foreground" />
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground line-clamp-2 leading-relaxed">
                        {section.content.substring(0, 150)}...
                      </p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="qualities" className="space-y-4">
            <Card className="bg-gradient-to-br from-primary/5 to-accent/5 border-primary/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-xl">
                  <Heart className="h-5 w-5 text-primary" />
                  ڕەوشتە بەرزەکانی پێغەمبەر ﷺ
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground leading-relaxed">
                  پێغەمبەر ﷺ نموونەی تەواو بوو لە ڕەوشتی باش. خودای گەورە فەرمووی: 
                  <span className="block text-xl text-primary mt-2 font-serif">
                    {"\"وَإِنَّكَ لَعَلَىٰ خُلُقٍ عَظِيمٍ\""}
                  </span>
                  <span className="block mt-1">
                    {"\"بێگومان تۆ بە ڕەوشتێکی گەورەوە ڕازێندراوی\""}
                  </span>
                </p>
              </CardContent>
            </Card>

            <div className="grid gap-4 sm:grid-cols-2">
              {prophetQualities.map((item, index) => (
                <Card key={index} className="transition-all hover:shadow-md">
                  <CardHeader className="pb-2">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{item.quality}</CardTitle>
                      <span className="text-primary text-xl font-serif">{item.arabic}</span>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground leading-relaxed">{item.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Card className="bg-muted/50">
              <CardContent className="pt-6">
                <blockquote className="border-r-4 border-primary pr-4">
                  <p className="text-lg leading-loose">
                    {"\"تەنها ناردراوم بۆ تەواوکردنی ڕەوشتە باشەکان\""}
                  </p>
                  <footer className="mt-2 text-muted-foreground">
                    — پێغەمبەر محمد ﷺ
                  </footer>
                </blockquote>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
