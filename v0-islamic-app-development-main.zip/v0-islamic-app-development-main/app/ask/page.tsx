'use client'

import { useState, useRef, useEffect } from 'react'
import { useChat } from '@ai-sdk/react'
import { DefaultChatTransport } from 'ai'
import { Send, MessageCircle, User, Sparkles, ArrowRight } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent } from '@/components/ui/card'
import { BottomNav } from '@/components/bottom-nav'
import { PageHeader } from '@/components/page-header'
import { cn } from '@/lib/utils'
import Link from 'next/link'

const categories = [
  { id: 'prayer', name: 'نوێژ', icon: '🕌' },
  { id: 'fasting', name: 'ڕۆژوو', icon: '🌙' },
  { id: 'zakat', name: 'زەکات', icon: '💰' },
  { id: 'hajj', name: 'حەج', icon: '🕋' },
  { id: 'marriage', name: 'هاوسەرگیری', icon: '💍' },
  { id: 'inheritance', name: 'میراث', icon: '⚖️' },
]

const popularQuestions = [
  'چۆن بۆ نوێژی سوبح بهێڵمەوە؟',
  'شەرتەکانی ڕۆژوو چین؟',
  'زەکات کەی واجب دەبێت؟',
  'چۆن حوکمی سوود وەردەگرتن چییە؟',
]

export default function AskPage() {
  const [input, setInput] = useState('')
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const { messages, sendMessage, status } = useChat({
    transport: new DefaultChatTransport({ api: '/api/chat' }),
  })

  const isLoading = status === 'streaming' || status === 'submitted'

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim() || isLoading) return
    
    const prefix = selectedCategory 
      ? `[بابەت: ${categories.find(c => c.id === selectedCategory)?.name}] `
      : ''
    
    sendMessage({ text: prefix + input })
    setInput('')
  }

  const handleQuestionClick = (question: string) => {
    sendMessage({ text: question })
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <PageHeader title="پرسیار و وەڵام" subtitle="پرسیارە شەرعییەکانت بکە" />

      <main className="flex-1 overflow-hidden flex flex-col pb-40">
        <div className="flex-1 overflow-y-auto px-4 py-4">
          {messages.length === 0 ? (
            <div className="space-y-6">
              {/* AI Assistant Link */}
              <Link href="/ai-assistant">
                <Card className="border-0 bg-gradient-to-br from-primary/90 to-primary shadow-lg">
                  <CardContent className="p-4 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary-foreground/20">
                        <Sparkles className="h-6 w-6 text-primary-foreground" />
                      </div>
                      <div>
                        <h3 className="font-bold text-primary-foreground">یاریدەدەری AI</h3>
                        <p className="text-sm text-primary-foreground/80">چاتبۆتی زیرەک بۆ پرسیارەکانت</p>
                      </div>
                    </div>
                    <ArrowRight className="h-5 w-5 text-primary-foreground rotate-180" />
                  </CardContent>
                </Card>
              </Link>

              {/* Categories */}
              <div>
                <h2 className="text-lg font-bold text-foreground mb-3">بابەت هەڵبژێرە</h2>
                <div className="grid grid-cols-3 gap-2">
                  {categories.map((category) => (
                    <Button
                      key={category.id}
                      variant={selectedCategory === category.id ? 'default' : 'outline'}
                      className="h-auto py-3 flex-col gap-1"
                      onClick={() => setSelectedCategory(
                        selectedCategory === category.id ? null : category.id
                      )}
                    >
                      <span className="text-xl">{category.icon}</span>
                      <span className="text-xs">{category.name}</span>
                    </Button>
                  ))}
                </div>
              </div>

              {/* Popular Questions */}
              <div>
                <h2 className="text-lg font-bold text-foreground mb-3">پرسیارە باوەکان</h2>
                <div className="space-y-2">
                  {popularQuestions.map((question, index) => (
                    <Button
                      key={index}
                      variant="outline"
                      className="w-full justify-start text-right h-auto py-3"
                      onClick={() => handleQuestionClick(question)}
                    >
                      <MessageCircle className="h-4 w-4 ml-2 text-primary shrink-0" />
                      <span className="line-clamp-2">{question}</span>
                    </Button>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-4 max-w-2xl mx-auto">
              {messages.map((message) => {
                const isUser = message.role === 'user'
                const text = message.parts
                  ?.filter((p): p is { type: 'text'; text: string } => p.type === 'text')
                  .map((p) => p.text)
                  .join('') || ''

                return (
                  <div
                    key={message.id}
                    className={cn(
                      'flex gap-3',
                      isUser ? 'flex-row-reverse' : 'flex-row'
                    )}
                  >
                    <div
                      className={cn(
                        'flex h-10 w-10 shrink-0 items-center justify-center rounded-xl',
                        isUser
                          ? 'bg-primary text-primary-foreground'
                          : 'bg-secondary text-secondary-foreground'
                      )}
                    >
                      {isUser ? (
                        <User className="h-5 w-5" />
                      ) : (
                        <MessageCircle className="h-5 w-5" />
                      )}
                    </div>
                    <Card
                      className={cn(
                        'max-w-[85%] border-0',
                        isUser
                          ? 'bg-primary text-primary-foreground'
                          : 'bg-card'
                      )}
                    >
                      <CardContent className="p-3">
                        <p className="whitespace-pre-wrap leading-relaxed">
                          {text}
                        </p>
                      </CardContent>
                    </Card>
                  </div>
                )
              })}

              {isLoading && messages[messages.length - 1]?.role === 'user' && (
                <div className="flex gap-3">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-secondary">
                    <MessageCircle className="h-5 w-5" />
                  </div>
                  <Card className="border-0 bg-card">
                    <CardContent className="p-3">
                      <div className="flex gap-1">
                        <span className="h-2 w-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: '0ms' }} />
                        <span className="h-2 w-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: '150ms' }} />
                        <span className="h-2 w-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: '300ms' }} />
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        {/* Input Area */}
        <div className="fixed bottom-20 left-0 right-0 border-t bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/80 p-4">
          <form onSubmit={handleSubmit} className="max-w-2xl mx-auto">
            <div className="relative">
              <Textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="پرسیارەکەت بنووسە..."
                className="min-h-[48px] max-h-32 resize-none pr-4 pl-12 py-3"
                rows={1}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault()
                    handleSubmit(e)
                  }
                }}
                disabled={isLoading}
              />
              <Button
                type="submit"
                size="icon"
                disabled={!input.trim() || isLoading}
                className="absolute left-2 top-1/2 -translate-y-1/2 h-8 w-8 rounded-lg"
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </form>
        </div>
      </main>

      <BottomNav />
    </div>
  )
}
