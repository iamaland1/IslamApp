'use client'

import { use, useState, useEffect } from 'react'
import { ArrowRight, Play, Pause, BookOpen } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { BottomNav } from '@/components/bottom-nav'
import { surahs } from '@/lib/quran-data'
import Link from 'next/link'

interface SurahPageProps {
  params: Promise<{ id: string }>
}

// Sample verses data (in production, this would come from an API)
const getVerses = (surahId: number) => {
  // Bismillah for all surahs except At-Tawbah (9)
  const bismillah = surahId !== 9 ? 'بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ' : ''
  
  const surahVerses: Record<number, string[]> = {
    1: [
      'الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ',
      'الرَّحْمَنِ الرَّحِيمِ',
      'مَالِكِ يَوْمِ الدِّينِ',
      'إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ',
      'اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ',
      'صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلاَ الضَّالِّينَ',
    ],
    112: [
      'قُلْ هُوَ اللَّهُ أَحَدٌ',
      'اللَّهُ الصَّمَدُ',
      'لَمْ يَلِدْ وَلَمْ يُولَدْ',
      'وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ',
    ],
    113: [
      'قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ',
      'مِن شَرِّ مَا خَلَقَ',
      'وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ',
      'وَمِن شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ',
      'وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ',
    ],
    114: [
      'قُلْ أَعُوذُ بِرَبِّ النَّاسِ',
      'مَلِكِ النَّاسِ',
      'إِلَهِ النَّاسِ',
      'مِن شَرِّ الْوَسْوَاسِ الْخَنَّاسِ',
      'الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ',
      'مِنَ الْجِنَّةِ وَالنَّاسِ',
    ],
    36: [
      'يس',
      'وَالْقُرْآنِ الْحَكِيمِ',
      'إِنَّكَ لَمِنَ الْمُرْسَلِينَ',
      'عَلَى صِرَاطٍ مُّسْتَقِيمٍ',
      'تَنزِيلَ الْعَزِيزِ الرَّحِيمِ',
    ],
    67: [
      'تَبَارَكَ الَّذِي بِيَدِهِ الْمُلْكُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ',
      'الَّذِي خَلَقَ الْمَوْتَ وَالْحَيَاةَ لِيَبْلُوَكُمْ أَيُّكُمْ أَحْسَنُ عَمَلاً وَهُوَ الْعَزِيزُ الْغَفُورُ',
      'الَّذِي خَلَقَ سَبْعَ سَمَاوَاتٍ طِبَاقاً مَّا تَرَى فِي خَلْقِ الرَّحْمَنِ مِن تَفَاوُتٍ',
    ],
  }
  
  return { bismillah, verses: surahVerses[surahId] || [] }
}

export default function SurahPage({ params }: SurahPageProps) {
  const resolvedParams = use(params)
  const surahId = parseInt(resolvedParams.id)
  const surah = surahs.find((s) => s.id === surahId)
  const [isPlaying, setIsPlaying] = useState(false)
  const [fontSize, setFontSize] = useState(24)

  if (!surah) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground">سورەکە نەدۆزرایەوە</p>
      </div>
    )
  }

  const { bismillah, verses } = getVerses(surahId)

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/80">
        <div className="flex items-center justify-between px-4 py-3">
          <Link href="/quran">
            <Button variant="ghost" size="icon" className="rounded-full">
              <ArrowRight className="h-5 w-5" />
            </Button>
          </Link>
          <div className="text-center">
            <h1 className="text-lg font-bold text-foreground">
              سورەی {surah.nameArabic}
            </h1>
            <p className="text-xs text-muted-foreground">
              {surah.meaning} • {surah.verses} ئایەت
            </p>
          </div>
          <Badge
            variant="secondary"
            className={`${
              surah.type === 'مەکی'
                ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400'
                : 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400'
            }`}
          >
            {surah.type}
          </Badge>
        </div>
      </header>

      <main className="px-4 py-6">
        {/* Surah Info Card */}
        <Card className="mb-6 border-0 bg-gradient-to-br from-primary/90 to-primary shadow-lg">
          <CardContent className="p-6 text-center">
            <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-primary-foreground/20 mx-auto mb-4">
              <BookOpen className="h-8 w-8 text-primary-foreground" />
            </div>
            <h2 className="text-3xl font-bold text-primary-foreground mb-2">
              {surah.nameArabic}
            </h2>
            <p className="text-primary-foreground/80">
              {surah.name} - {surah.meaning}
            </p>
            <div className="flex items-center justify-center gap-4 mt-4">
              <span className="text-sm text-primary-foreground/70">
                {surah.verses} ئایەت
              </span>
              <span className="text-primary-foreground/40">•</span>
              <span className="text-sm text-primary-foreground/70">
                {surah.type}
              </span>
            </div>
          </CardContent>
        </Card>

        {/* Controls */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setFontSize((f) => Math.max(16, f - 2))}
            >
              A-
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setFontSize((f) => Math.min(36, f + 2))}
            >
              A+
            </Button>
          </div>
          <Button
            variant="secondary"
            size="sm"
            onClick={() => setIsPlaying(!isPlaying)}
            className="gap-2"
          >
            {isPlaying ? (
              <>
                <Pause className="h-4 w-4" /> وەستان
              </>
            ) : (
              <>
                <Play className="h-4 w-4" /> گوێگرتن
              </>
            )}
          </Button>
        </div>

        {/* Bismillah */}
        {bismillah && (
          <div className="text-center mb-8">
            <p
              className="text-2xl font-bold text-primary leading-loose"
              style={{ fontSize: `${fontSize + 4}px` }}
            >
              {bismillah}
            </p>
          </div>
        )}

        {/* Verses */}
        {verses.length > 0 ? (
          <div className="space-y-4">
            {verses.map((verse, index) => (
              <Card key={index} className="border-0 bg-card shadow-sm">
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10 shrink-0">
                      <span className="text-sm font-bold text-primary">
                        {index + 1}
                      </span>
                    </div>
                    <p
                      className="text-foreground leading-loose flex-1"
                      style={{ fontSize: `${fontSize}px` }}
                      dir="rtl"
                    >
                      {verse}
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="border-0 bg-secondary/50">
            <CardContent className="p-8 text-center">
              <BookOpen className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <p className="text-muted-foreground">
                ئایەتەکانی ئەم سورەیە لە نسخەی داهاتوودا زیاد دەکرێن
              </p>
              <p className="text-xs text-muted-foreground mt-2">
                {surah.verses} ئایەت
              </p>
            </CardContent>
          </Card>
        )}

        {/* Navigation */}
        <div className="flex items-center justify-between mt-8">
          {surahId > 1 && (
            <Link href={`/quran/${surahId - 1}`}>
              <Button variant="outline" className="gap-2">
                <ArrowRight className="h-4 w-4" />
                {surahs[surahId - 2]?.name}
              </Button>
            </Link>
          )}
          {surahId < 114 && (
            <Link href={`/quran/${surahId + 1}`} className="mr-auto">
              <Button variant="outline" className="gap-2">
                {surahs[surahId]?.name}
                <ArrowRight className="h-4 w-4 rotate-180" />
              </Button>
            </Link>
          )}
        </div>
      </main>

      <BottomNav />
    </div>
  )
}
