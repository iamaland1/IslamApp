'use client'

import { useState } from 'react'
import { Search, BookOpen, ChevronLeft } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { BottomNav } from '@/components/bottom-nav'
import { PageHeader } from '@/components/page-header'
import { surahs } from '@/lib/quran-data'
import Link from 'next/link'

export default function QuranPage() {
  const [searchQuery, setSearchQuery] = useState('')

  const filteredSurahs = surahs.filter(
    (surah) =>
      surah.name.includes(searchQuery) ||
      surah.nameArabic.includes(searchQuery) ||
      surah.meaning.includes(searchQuery) ||
      surah.id.toString().includes(searchQuery)
  )

  return (
    <div className="min-h-screen bg-background pb-24">
      <PageHeader title="قورئانی پیرۆز" subtitle="١١٤ سورە" />

      <main className="px-4 py-4">
        {/* Search */}
        <div className="relative mb-4">
          <Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="گەڕان بەدوای سورەدا..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pr-10 bg-card border-border"
          />
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-2 mb-4">
          <Card className="border-0 bg-primary/10">
            <CardContent className="p-3 text-center">
              <p className="text-2xl font-bold text-primary">١١٤</p>
              <p className="text-xs text-muted-foreground">سورە</p>
            </CardContent>
          </Card>
          <Card className="border-0 bg-accent/30">
            <CardContent className="p-3 text-center">
              <p className="text-2xl font-bold text-accent-foreground">٦٢٣٦</p>
              <p className="text-xs text-muted-foreground">ئایەت</p>
            </CardContent>
          </Card>
          <Card className="border-0 bg-secondary">
            <CardContent className="p-3 text-center">
              <p className="text-2xl font-bold text-secondary-foreground">٣٠</p>
              <p className="text-xs text-muted-foreground">جوز</p>
            </CardContent>
          </Card>
        </div>

        {/* Surah List */}
        <div className="space-y-2">
          {filteredSurahs.map((surah) => (
            <Link key={surah.id} href={`/quran/${surah.id}`}>
              <Card className="border-0 bg-card shadow-sm hover:shadow-md transition-all duration-200 hover:-translate-y-0.5">
                <CardContent className="p-4">
                  <div className="flex items-center gap-4">
                    <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
                      <span className="font-bold text-primary">{surah.id}</span>
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <h3 className="font-bold text-foreground text-lg">
                          {surah.nameArabic}
                        </h3>
                        <Badge
                          variant="secondary"
                          className={`text-xs ${
                            surah.type === 'مەکی'
                              ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400'
                              : 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400'
                          }`}
                        >
                          {surah.type}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {surah.meaning} • {surah.verses} ئایەت
                      </p>
                    </div>
                    <ChevronLeft className="h-5 w-5 text-muted-foreground" />
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>

        {filteredSurahs.length === 0 && (
          <div className="text-center py-12">
            <BookOpen className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <p className="text-muted-foreground">هیچ سورەیەک نەدۆزرایەوە</p>
          </div>
        )}
      </main>

      <BottomNav />
    </div>
  )
}
