'use client'

import { useState, useEffect, useCallback } from 'react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { 
  quizCategories, 
  quizQuestions, 
  getQuestionsByCategory,
  type QuizQuestion 
} from '@/lib/quiz-data'
import { 
  Trophy, 
  Clock, 
  CheckCircle, 
  XCircle, 
  RotateCcw,
  ArrowRight,
  BookOpen,
  Star,
  Zap
} from 'lucide-react'
import PageHeader from '@/components/page-header'
import { cn } from '@/lib/utils'

type GameState = 'menu' | 'playing' | 'result'
type Difficulty = 'all' | 'easy' | 'medium' | 'hard'

export default function QuizPage() {
  const [gameState, setGameState] = useState<GameState>('menu')
  const [selectedCategory, setSelectedCategory] = useState<string>('all')
  const [difficulty, setDifficulty] = useState<Difficulty>('all')
  const [questions, setQuestions] = useState<QuizQuestion[]>([])
  const [currentIndex, setCurrentIndex] = useState(0)
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null)
  const [showExplanation, setShowExplanation] = useState(false)
  const [score, setScore] = useState(0)
  const [timeLeft, setTimeLeft] = useState(30)
  const [isTimerActive, setIsTimerActive] = useState(false)
  const [answeredQuestions, setAnsweredQuestions] = useState<{correct: boolean, questionId: number}[]>([])

  const handleTimeUp = useCallback(() => {
    if (selectedAnswer === null) {
      setSelectedAnswer(-1) // Mark as unanswered
      setShowExplanation(true)
      setAnsweredQuestions(prev => [...prev, { correct: false, questionId: questions[currentIndex].id }])
    }
  }, [selectedAnswer, currentIndex, questions])

  useEffect(() => {
    let timer: NodeJS.Timeout
    if (isTimerActive && timeLeft > 0 && !showExplanation) {
      timer = setTimeout(() => setTimeLeft(t => t - 1), 1000)
    } else if (timeLeft === 0 && !showExplanation) {
      handleTimeUp()
    }
    return () => clearTimeout(timer)
  }, [timeLeft, isTimerActive, showExplanation, handleTimeUp])

  const startQuiz = () => {
    let filteredQuestions = getQuestionsByCategory(selectedCategory)
    
    if (difficulty !== 'all') {
      filteredQuestions = filteredQuestions.filter(q => q.difficulty === difficulty)
    }

    // Shuffle and take 10 questions
    const shuffled = [...filteredQuestions].sort(() => Math.random() - 0.5).slice(0, 10)
    setQuestions(shuffled)
    setCurrentIndex(0)
    setScore(0)
    setSelectedAnswer(null)
    setShowExplanation(false)
    setAnsweredQuestions([])
    setTimeLeft(30)
    setIsTimerActive(true)
    setGameState('playing')
  }

  const handleAnswerSelect = (answerIndex: number) => {
    if (selectedAnswer !== null) return

    setSelectedAnswer(answerIndex)
    setShowExplanation(true)
    setIsTimerActive(false)

    const isCorrect = answerIndex === questions[currentIndex].correctAnswer
    if (isCorrect) {
      setScore(s => s + 1)
    }
    setAnsweredQuestions(prev => [...prev, { correct: isCorrect, questionId: questions[currentIndex].id }])
  }

  const nextQuestion = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(i => i + 1)
      setSelectedAnswer(null)
      setShowExplanation(false)
      setTimeLeft(30)
      setIsTimerActive(true)
    } else {
      setGameState('result')
    }
  }

  const getDifficultyLabel = (diff: string) => {
    const labels: Record<string, string> = {
      easy: 'ئاسان',
      medium: 'مامناوەند',
      hard: 'قورس',
      all: 'هەموو'
    }
    return labels[diff] || diff
  }

  const getDifficultyColor = (diff: string) => {
    const colors: Record<string, string> = {
      easy: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-200',
      medium: 'bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200',
      hard: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
    }
    return colors[diff] || ''
  }

  const currentQuestion = questions[currentIndex]

  if (gameState === 'menu') {
    return (
      <div className="min-h-screen bg-background pb-24">
        <PageHeader 
          title="یاری پرسیار و وەڵام"
          subtitle="تاقیکردنەوەی زانیارییەکانت"
        />

        <main className="container mx-auto px-4 py-6 space-y-6">
          {/* Category Selection */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <BookOpen className="h-5 w-5 text-primary" />
                بابەت هەڵبژێرە
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button
                variant={selectedCategory === 'all' ? 'default' : 'outline'}
                className="w-full justify-start"
                onClick={() => setSelectedCategory('all')}
              >
                <Star className="h-4 w-4 ml-2" />
                هەموو بابەتەکان ({quizQuestions.length} پرسیار)
              </Button>
              
              {quizCategories.map(cat => (
                <Button
                  key={cat.id}
                  variant={selectedCategory === cat.id ? 'default' : 'outline'}
                  className="w-full justify-start"
                  onClick={() => setSelectedCategory(cat.id)}
                >
                  <span className="ml-2">{cat.icon}</span>
                  {cat.name} ({cat.questionCount} پرسیار)
                </Button>
              ))}
            </CardContent>
          </Card>

          {/* Difficulty Selection */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Zap className="h-5 w-5 text-primary" />
                ئاستی سەختی
              </CardTitle>
            </CardHeader>
            <CardContent className="flex flex-wrap gap-2">
              {(['all', 'easy', 'medium', 'hard'] as Difficulty[]).map(diff => (
                <Button
                  key={diff}
                  variant={difficulty === diff ? 'default' : 'outline'}
                  onClick={() => setDifficulty(diff)}
                >
                  {getDifficultyLabel(diff)}
                </Button>
              ))}
            </CardContent>
          </Card>

          {/* Start Button */}
          <Button 
            size="lg" 
            className="w-full text-lg py-6"
            onClick={startQuiz}
          >
            دەستپێکردنی یاری
            <ArrowRight className="h-5 w-5 mr-2" />
          </Button>

          {/* Stats Card */}
          <Card className="bg-gradient-to-br from-primary/5 to-accent/5">
            <CardContent className="pt-6">
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <div className="text-3xl font-bold text-primary">{quizQuestions.length}</div>
                  <div className="text-sm text-muted-foreground">کۆی پرسیارەکان</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-primary">5</div>
                  <div className="text-sm text-muted-foreground">بابەت</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-primary">3</div>
                  <div className="text-sm text-muted-foreground">ئاست</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    )
  }

  if (gameState === 'playing' && currentQuestion) {
    return (
      <div className="min-h-screen bg-background pb-24">
        <div className="sticky top-0 bg-background border-b z-10 px-4 py-3">
          <div className="container mx-auto flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Badge variant="outline">
                {currentIndex + 1} / {questions.length}
              </Badge>
              <Badge className={getDifficultyColor(currentQuestion.difficulty)}>
                {getDifficultyLabel(currentQuestion.difficulty)}
              </Badge>
            </div>
            <div className="flex items-center gap-2">
              <Trophy className="h-4 w-4 text-primary" />
              <span className="font-bold">{score}</span>
            </div>
          </div>
        </div>

        <main className="container mx-auto px-4 py-6 space-y-6">
          {/* Timer */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Clock className={cn("h-4 w-4", timeLeft <= 10 ? "text-destructive" : "text-primary")} />
                <span className={cn("font-bold", timeLeft <= 10 ? "text-destructive" : "")}>
                  {timeLeft} چرکە
                </span>
              </div>
              <Progress 
                value={(timeLeft / 30) * 100} 
                className={cn("w-1/2 h-2", timeLeft <= 10 ? "[&>div]:bg-destructive" : "")}
              />
            </div>
          </div>

          {/* Question Card */}
          <Card>
            <CardHeader>
              <CardTitle className="text-xl leading-relaxed">
                {currentQuestion.question}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {currentQuestion.options.map((option, idx) => {
                const isSelected = selectedAnswer === idx
                const isCorrect = idx === currentQuestion.correctAnswer
                const showResult = selectedAnswer !== null

                return (
                  <Button
                    key={idx}
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-right h-auto py-4 px-4 whitespace-normal",
                      showResult && isCorrect && "border-emerald-500 bg-emerald-50 dark:bg-emerald-950",
                      showResult && isSelected && !isCorrect && "border-destructive bg-destructive/10",
                      !showResult && "hover:border-primary"
                    )}
                    onClick={() => handleAnswerSelect(idx)}
                    disabled={selectedAnswer !== null}
                  >
                    <span className={cn(
                      "w-8 h-8 rounded-full flex items-center justify-center ml-3 shrink-0",
                      showResult && isCorrect ? "bg-emerald-500 text-white" :
                      showResult && isSelected && !isCorrect ? "bg-destructive text-white" :
                      "bg-muted"
                    )}>
                      {showResult && isCorrect ? (
                        <CheckCircle className="h-5 w-5" />
                      ) : showResult && isSelected && !isCorrect ? (
                        <XCircle className="h-5 w-5" />
                      ) : (
                        String.fromCharCode(1632 + idx + 1) // Arabic numerals
                      )}
                    </span>
                    <span className="flex-1">{option}</span>
                  </Button>
                )
              })}
            </CardContent>
          </Card>

          {/* Explanation */}
          {showExplanation && currentQuestion.explanation && (
            <Card className="bg-muted/50 border-primary/20">
              <CardContent className="pt-6">
                <p className="text-muted-foreground leading-relaxed">
                  <span className="font-bold text-foreground">ڕوونکردنەوە: </span>
                  {currentQuestion.explanation}
                </p>
              </CardContent>
            </Card>
          )}

          {/* Next Button */}
          {showExplanation && (
            <Button 
              size="lg" 
              className="w-full"
              onClick={nextQuestion}
            >
              {currentIndex < questions.length - 1 ? 'پرسیاری دواتر' : 'بینینی ئەنجام'}
              <ArrowRight className="h-5 w-5 mr-2" />
            </Button>
          )}
        </main>
      </div>
    )
  }

  if (gameState === 'result') {
    const percentage = Math.round((score / questions.length) * 100)
    const getMessage = () => {
      if (percentage >= 90) return 'ئافەرین! نایاب بوویت!'
      if (percentage >= 70) return 'زۆر باشە! بەردەوام بە!'
      if (percentage >= 50) return 'باشە! هێشتا جێگای باشترکردن هەیە'
      return 'هەوڵ بدەوە دووبارە!'
    }

    return (
      <div className="min-h-screen bg-background pb-24">
        <PageHeader 
          title="ئەنجامی یاری"
          subtitle={getMessage()}
        />

        <main className="container mx-auto px-4 py-6 space-y-6">
          {/* Score Card */}
          <Card className="bg-gradient-to-br from-primary/10 to-accent/10 border-primary/20">
            <CardContent className="pt-6 text-center">
              <div className="relative inline-block mb-4">
                <div className="w-32 h-32 rounded-full border-8 border-primary/20 flex items-center justify-center">
                  <div>
                    <div className="text-4xl font-bold text-primary">{percentage}٪</div>
                    <div className="text-sm text-muted-foreground">{score} لە {questions.length}</div>
                  </div>
                </div>
                <Trophy className="absolute -top-2 -right-2 h-10 w-10 text-accent" />
              </div>

              <div className="flex justify-center gap-4 mt-6">
                <div className="text-center">
                  <div className="w-12 h-12 rounded-full bg-emerald-100 dark:bg-emerald-900 flex items-center justify-center mx-auto mb-1">
                    <CheckCircle className="h-6 w-6 text-emerald-600 dark:text-emerald-400" />
                  </div>
                  <div className="font-bold">{score}</div>
                  <div className="text-xs text-muted-foreground">ڕاست</div>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 rounded-full bg-red-100 dark:bg-red-900 flex items-center justify-center mx-auto mb-1">
                    <XCircle className="h-6 w-6 text-red-600 dark:text-red-400" />
                  </div>
                  <div className="font-bold">{questions.length - score}</div>
                  <div className="text-xs text-muted-foreground">هەڵە</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Question Review */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">پێداچوونەوەی پرسیارەکان</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {answeredQuestions.map((answer, idx) => {
                const question = questions.find(q => q.id === answer.questionId)
                if (!question) return null

                return (
                  <div 
                    key={idx}
                    className={cn(
                      "flex items-center gap-3 p-3 rounded-lg",
                      answer.correct ? "bg-emerald-50 dark:bg-emerald-950/50" : "bg-red-50 dark:bg-red-950/50"
                    )}
                  >
                    {answer.correct ? (
                      <CheckCircle className="h-5 w-5 text-emerald-600 shrink-0" />
                    ) : (
                      <XCircle className="h-5 w-5 text-red-600 shrink-0" />
                    )}
                    <span className="text-sm line-clamp-1">{question.question}</span>
                  </div>
                )
              })}
            </CardContent>
          </Card>

          {/* Action Buttons */}
          <div className="flex gap-3">
            <Button 
              variant="outline" 
              className="flex-1"
              onClick={() => setGameState('menu')}
            >
              <RotateCcw className="h-4 w-4 ml-2" />
              گەڕانەوە بۆ سەرەتا
            </Button>
            <Button 
              className="flex-1"
              onClick={startQuiz}
            >
              یاری نوێ
              <ArrowRight className="h-4 w-4 mr-2" />
            </Button>
          </div>
        </main>
      </div>
    )
  }

  return null
}
