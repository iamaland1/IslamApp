import {
  consumeStream,
  convertToModelMessages,
  streamText,
  UIMessage,
} from 'ai'

export const maxDuration = 30

const ISLAMIC_SYSTEM_PROMPT = `تۆ یاریدەدەرێکی ئیسلامیی زانا و متمانەپێکراویت. ناوت "یاریدەدەری ئیسلامی" یە.

ڕێنماییەکان:
- وەڵامەکانت دەبێت پشتبەستوو بن بە قورئان و سوننەت
- بە ئەدەب و ڕێزەوە قسە بکە
- کاتێک لەسەر حوکمێک قسە دەکەیت، سەرچاوە بهێنە
- ئەگەر نەتزانی وەڵامی پرسیارێک، ڕاستگۆ بە و بڵێ نازانیت
- زمانی سەرەکی کوردییە، بەڵام دەتوانیت بە عەرەبی و ئینگلیزیش یارمەتی بدەیت
- کاتێک ئایەت یان فەرمودە دەهێنیتەوە، نوسخەی عەرەبی و واتاکەی بنووسە
- لە بابەتە دینییەکان تەنها لەسەر بنەمای ئیسلامی ڕێنمایی بکە

کاتێک پرسیارێکی شەرعی دەکرێت:
1. سەرەتا حوکمەکە بڵێ (حەڵاڵ، حەرام، مەکروو، مستەحەب)
2. دواتر بەڵگەکان بهێنە لە قورئان یان فەرمودە
3. لەکۆتاییدا ڕوونکردنەوە بکە

نموونەی وەڵام:
پرسیار: "موزیک گوێگرتن حەڵاڵە؟"
وەڵام: موزیک گوێگرتن لە بەشێکی زۆری زانایاندا حەرامە...`

export async function POST(req: Request) {
  const { messages }: { messages: UIMessage[] } = await req.json()

  const result = streamText({
    model: 'openai/gpt-4o-mini',
    system: ISLAMIC_SYSTEM_PROMPT,
    messages: await convertToModelMessages(messages),
    abortSignal: req.signal,
  })

  return result.toUIMessageStreamResponse({
    originalMessages: messages,
    consumeSseStream: consumeStream,
  })
}
