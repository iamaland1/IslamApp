'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import { Slider } from '@/components/ui/slider'
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { 
  Settings, 
  Moon, 
  Sun, 
  Type, 
  Bell, 
  Volume2,
  Globe,
  Palette,
  Info,
  ChevronLeft
} from 'lucide-react'
import Link from 'next/link'
import PageHeader from '@/components/page-header'

interface AppSettings {
  theme: 'light' | 'dark' | 'system'
  fontSize: number
  notifications: boolean
  soundEnabled: boolean
  autoPlayAudio: boolean
  language: 'ckb' | 'ar' | 'en'
}

const defaultSettings: AppSettings = {
  theme: 'system',
  fontSize: 18,
  notifications: true,
  soundEnabled: true,
  autoPlayAudio: false,
  language: 'ckb'
}

export default function SettingsPage() {
  const [settings, setSettings] = useState<AppSettings>(defaultSettings)

  useEffect(() => {
    const savedSettings = localStorage.getItem('islamicAppSettings')
    if (savedSettings) {
      setSettings(JSON.parse(savedSettings))
    }
  }, [])

  useEffect(() => {
    localStorage.setItem('islamicAppSettings', JSON.stringify(settings))
    
    // Apply theme
    if (settings.theme === 'dark') {
      document.documentElement.classList.add('dark')
    } else if (settings.theme === 'light') {
      document.documentElement.classList.remove('dark')
    } else {
      // System preference
      if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
        document.documentElement.classList.add('dark')
      } else {
        document.documentElement.classList.remove('dark')
      }
    }
  }, [settings])

  const updateSetting = <K extends keyof AppSettings>(key: K, value: AppSettings[K]) => {
    setSettings(prev => ({ ...prev, [key]: value }))
  }

  return (
    <div className="min-h-screen bg-background pb-24">
      <PageHeader 
        title="ڕێکخستنەکان"
        subtitle="ڕێکخستنی بەرنامەکە"
      />

      <main className="container mx-auto px-4 py-6 space-y-4">
        {/* Appearance Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Palette className="h-5 w-5 text-primary" />
              ڕوانگە
            </CardTitle>
            <CardDescription>ڕێکخستنی ڕووکاری بەرنامەکە</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Theme Selection */}
            <div className="space-y-2">
              <Label>تەما</Label>
              <div className="flex gap-2">
                <Button
                  variant={settings.theme === 'light' ? 'default' : 'outline'}
                  className="flex-1"
                  onClick={() => updateSetting('theme', 'light')}
                >
                  <Sun className="h-4 w-4 ml-2" />
                  ڕووناک
                </Button>
                <Button
                  variant={settings.theme === 'dark' ? 'default' : 'outline'}
                  className="flex-1"
                  onClick={() => updateSetting('theme', 'dark')}
                >
                  <Moon className="h-4 w-4 ml-2" />
                  تاریک
                </Button>
                <Button
                  variant={settings.theme === 'system' ? 'default' : 'outline'}
                  className="flex-1"
                  onClick={() => updateSetting('theme', 'system')}
                >
                  <Settings className="h-4 w-4 ml-2" />
                  سیستەم
                </Button>
              </div>
            </div>

            {/* Font Size */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Label className="flex items-center gap-2">
                  <Type className="h-4 w-4" />
                  قەبارەی فۆنت
                </Label>
                <span className="text-sm text-muted-foreground">{settings.fontSize}px</span>
              </div>
              <Slider
                value={[settings.fontSize]}
                onValueChange={([value]) => updateSetting('fontSize', value)}
                min={14}
                max={28}
                step={2}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>بچووک</span>
                <span>گەورە</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Language Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Globe className="h-5 w-5 text-primary" />
              زمان
            </CardTitle>
            <CardDescription>زمانی بەرنامەکە هەڵبژێرە</CardDescription>
          </CardHeader>
          <CardContent>
            <Select
              value={settings.language}
              onValueChange={(value: 'ckb' | 'ar' | 'en') => updateSetting('language', value)}
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="زمان هەڵبژێرە" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ckb">کوردی سۆرانی</SelectItem>
                <SelectItem value="ar">عربی</SelectItem>
                <SelectItem value="en">English</SelectItem>
              </SelectContent>
            </Select>
          </CardContent>
        </Card>

        {/* Notification Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Bell className="h-5 w-5 text-primary" />
              ئاگادارکردنەوەکان
            </CardTitle>
            <CardDescription>ڕێکخستنی ئاگادارکردنەوەکان</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="notifications" className="flex-1">
                ئاگادارکردنەوەی کاتی نوێژ
                <p className="text-sm text-muted-foreground font-normal">
                  ئاگادارت دەکاتەوە لە کاتی نوێژەکان
                </p>
              </Label>
              <Switch
                id="notifications"
                checked={settings.notifications}
                onCheckedChange={(checked) => updateSetting('notifications', checked)}
              />
            </div>
          </CardContent>
        </Card>

        {/* Sound Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Volume2 className="h-5 w-5 text-primary" />
              دەنگ
            </CardTitle>
            <CardDescription>ڕێکخستنی دەنگەکان</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="sound" className="flex-1">
                دەنگی بەرنامە
                <p className="text-sm text-muted-foreground font-normal">
                  چالاککردنی دەنگەکان
                </p>
              </Label>
              <Switch
                id="sound"
                checked={settings.soundEnabled}
                onCheckedChange={(checked) => updateSetting('soundEnabled', checked)}
              />
            </div>

            <div className="flex items-center justify-between">
              <Label htmlFor="autoplay" className="flex-1">
                لێدانی خۆکارانەی قورئان
                <p className="text-sm text-muted-foreground font-normal">
                  دەنگی قورئان خۆکار لێ بدات
                </p>
              </Label>
              <Switch
                id="autoplay"
                checked={settings.autoPlayAudio}
                onCheckedChange={(checked) => updateSetting('autoPlayAudio', checked)}
              />
            </div>
          </CardContent>
        </Card>

        {/* About Link */}
        <Link href="/about">
          <Card className="hover:bg-muted/50 transition-colors cursor-pointer">
            <CardContent className="flex items-center justify-between py-4">
              <div className="flex items-center gap-3">
                <Info className="h-5 w-5 text-primary" />
                <div>
                  <p className="font-medium">دەربارەی بەرنامەکە</p>
                  <p className="text-sm text-muted-foreground">وەشانی ١.٠.٠</p>
                </div>
              </div>
              <ChevronLeft className="h-5 w-5 text-muted-foreground" />
            </CardContent>
          </Card>
        </Link>

        {/* Reset Settings */}
        <Button 
          variant="outline" 
          className="w-full"
          onClick={() => setSettings(defaultSettings)}
        >
          گەڕانەوە بۆ ڕێکخستنی بنەڕەتی
        </Button>
      </main>
    </div>
  )
}
