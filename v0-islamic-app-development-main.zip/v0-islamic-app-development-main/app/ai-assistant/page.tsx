'use client'

import { useState, useRef, useEffect } from 'react'
import { useChat } from '@ai-sdk/react'
import { DefaultChatTransport } from 'ai'
import { Send, Bot, User, Sparkles, Trash2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent } from '@/components/ui/card'
import { BottomNav } from '@/components/bottom-nav'
import { PageHeader } from '@/components/page-header'
import { cn } from '@/lib/utils'

const suggestedQuestions = [
  'چۆن نوێژ بکەم؟',
  'ڕۆژوو چ کاتێک واجبە؟',
  'میراث چۆن دابەش دەکرێت؟',
  'شەرتەکانی حەج چین؟',
]

export default function AIAssistantPage() {
  const [input, setInput] = useState('')
  const messagesEndRef = useRef<HTMLDivElement>(null)
  
  const { messages, sendMessage, status, setMessages } = useChat({
    transport: new DefaultChatTransport({ api: '/api/chat' }),
  })

  const isLoading = status === 'streaming' || status === 'submitted'

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim() || isLoading) return
    sendMessage({ text: input })
    setInput('')
  }

  const handleSuggestedQuestion = (question: string) => {
    sendMessage({ text: question })
  }

  const clearChat = () => {
    setMessages([])
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <PageHeader title="یاریدەدەری AI" subtitle="پرسیارەکانت بکە" />

      <main className="flex-1 overflow-hidden flex flex-col pb-40">
        <div className="flex-1 overflow-y-auto px-4 py-4">
          {messages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center px-4">
              <div className="flex h-20 w-20 items-center justify-center rounded-3xl bg-gradient-to-br from-primary to-primary/70 mb-6">
                <Bot className="h-10 w-10 text-primary-foreground" />
              </div>
              <h2 className="text-xl font-bold text-foreground mb-2">
                بەخێربێیت بۆ یاریدەدەری ئیسلامی
              </h2>
              <p className="text-muted-foreground mb-8 max-w-sm">
                من دەتوانم وەڵامی پرسیارە شەرعییەکانت بدەمەوە پشتبەستوو بە قورئان و سوننەت
              </p>
              
              <div className="w-full max-w-sm space-y-2">
                <p className="text-sm text-muted-foreground mb-3">
                  پرسیارێک هەڵبژێرە:
                </p>
                {suggestedQuestions.map((question, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    className="w-full justify-start text-right"
                    onClick={() => handleSuggestedQuestion(question)}
                  >
                    <Sparkles className="h-4 w-4 ml-2 text-primary" />
                    {question}
                  </Button>
                ))}
              </div>
            </div>
          ) : (
            <div className="space-y-4 max-w-2xl mx-auto">
              {messages.map((message) => {
                const isUser = message.role === 'user'
                const text = message.parts
                  ?.filter((p): p is { type: 'text'; text: string } => p.type === 'text')
                  .map((p) => p.text)
                  .join('') || ''

                return (
                  <div
                    key={message.id}
                    className={cn(
                      'flex gap-3',
                      isUser ? 'flex-row-reverse' : 'flex-row'
                    )}
                  >
                    <div
                      className={cn(
                        'flex h-10 w-10 shrink-0 items-center justify-center rounded-xl',
                        isUser
                          ? 'bg-primary text-primary-foreground'
                          : 'bg-secondary text-secondary-foreground'
                      )}
                    >
                      {isUser ? (
                        <User className="h-5 w-5" />
                      ) : (
                        <Bot className="h-5 w-5" />
                      )}
                    </div>
                    <Card
                      className={cn(
                        'max-w-[85%] border-0',
                        isUser
                          ? 'bg-primary text-primary-foreground'
                          : 'bg-card'
                      )}
                    >
                      <CardContent className="p-3">
                        <p className="whitespace-pre-wrap leading-relaxed">
                          {text}
                        </p>
                      </CardContent>
                    </Card>
                  </div>
                )
              })}

              {isLoading && messages[messages.length - 1]?.role === 'user' && (
                <div className="flex gap-3">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-secondary text-secondary-foreground">
                    <Bot className="h-5 w-5" />
                  </div>
                  <Card className="border-0 bg-card">
                    <CardContent className="p-3">
                      <div className="flex gap-1">
                        <span className="h-2 w-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: '0ms' }} />
                        <span className="h-2 w-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: '150ms' }} />
                        <span className="h-2 w-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: '300ms' }} />
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        {/* Input Area */}
        <div className="fixed bottom-20 left-0 right-0 border-t bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/80 p-4">
          <form onSubmit={handleSubmit} className="max-w-2xl mx-auto">
            <div className="flex gap-2">
              {messages.length > 0 && (
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  onClick={clearChat}
                  className="shrink-0"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              )}
              <div className="relative flex-1">
                <Textarea
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="پرسیارەکەت بنووسە..."
                  className="min-h-[48px] max-h-32 resize-none pr-4 pl-12 py-3"
                  rows={1}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault()
                      handleSubmit(e)
                    }
                  }}
                  disabled={isLoading}
                />
                <Button
                  type="submit"
                  size="icon"
                  disabled={!input.trim() || isLoading}
                  className="absolute left-2 top-1/2 -translate-y-1/2 h-8 w-8 rounded-lg"
                >
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </form>
        </div>
      </main>

      <BottomNav />
    </div>
  )
}
