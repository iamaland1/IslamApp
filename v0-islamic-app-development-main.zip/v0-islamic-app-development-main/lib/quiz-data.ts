export interface QuizQuestion {
  id: number
  question: string
  options: string[]
  correctAnswer: number
  category: 'quran' | 'hadith' | 'prophet' | 'fiqh' | 'general'
  difficulty: 'easy' | 'medium' | 'hard'
  explanation?: string
}

export interface QuizCategory {
  id: string
  name: string
  icon: string
  description: string
  questionCount: number
}

export const quizCategories: QuizCategory[] = [
  {
    id: 'quran',
    name: 'قورئان',
    icon: '📖',
    description: 'پرسیارەکان دەربارەی قورئانی پیرۆز',
    questionCount: 25
  },
  {
    id: 'hadith',
    name: 'حەدیس',
    icon: '📜',
    description: 'پرسیارەکان دەربارەی فەرموودەکانی پێغەمبەر ﷺ',
    questionCount: 25
  },
  {
    id: 'prophet',
    name: 'ژیانی پێغەمبەر',
    icon: '🕌',
    description: 'پرسیارەکان دەربارەی ژیانی پێغەمبەر ﷺ',
    questionCount: 25
  },
  {
    id: 'fiqh',
    name: 'فیقه',
    icon: '⚖️',
    description: 'پرسیارەکان دەربارەی حوکمەکانی ئیسلام',
    questionCount: 25
  },
  {
    id: 'general',
    name: 'گشتی',
    icon: '🌙',
    description: 'پرسیارە گشتییەکان دەربارەی ئیسلام',
    questionCount: 25
  }
]

export const quizQuestions: QuizQuestion[] = [
  // Quran Questions
  {
    id: 1,
    question: 'چەند سورەت لە قورئانی پیرۆزدا هەیە؟',
    options: ['١٠٠ سورەت', '١١٤ سورەت', '١٢٠ سورەت', '١٣٠ سورەت'],
    correctAnswer: 1,
    category: 'quran',
    difficulty: 'easy',
    explanation: 'قورئانی پیرۆز ١١٤ سورەتی تێدایە.'
  },
  {
    id: 2,
    question: 'یەکەم سورەتی قورئان کامەیە؟',
    options: ['سورەتی بەقەرە', 'سورەتی فاتیحە', 'سورەتی ناس', 'سورەتی ئیخلاس'],
    correctAnswer: 1,
    category: 'quran',
    difficulty: 'easy',
    explanation: 'سورەتی فاتیحە یەکەم سورەتی قورئانە و ٧ ئایەتی تێدایە.'
  },
  {
    id: 3,
    question: 'کۆتا سورەتی قورئان کامەیە؟',
    options: ['سورەتی فەلەق', 'سورەتی ناس', 'سورەتی کەوسەر', 'سورەتی ئیخلاس'],
    correctAnswer: 1,
    category: 'quran',
    difficulty: 'easy',
    explanation: 'سورەتی ناس کۆتا سورەتی قورئانە و ٦ ئایەتی تێدایە.'
  },
  {
    id: 4,
    question: 'کام سورەت بە "قەڵبی قورئان" ناسراوە؟',
    options: ['سورەتی بەقەرە', 'سورەتی یاسین', 'سورەتی ڕەحمان', 'سورەتی مولک'],
    correctAnswer: 1,
    category: 'quran',
    difficulty: 'medium',
    explanation: 'سورەتی یاسین بە "قەڵبی قورئان" ناسراوە.'
  },
  {
    id: 5,
    question: 'درێژترین سورەتی قورئان کامەیە؟',
    options: ['سورەتی ئالی عیمران', 'سورەتی بەقەرە', 'سورەتی نیسا', 'سورەتی مائیدە'],
    correctAnswer: 1,
    category: 'quran',
    difficulty: 'easy',
    explanation: 'سورەتی بەقەرە درێژترین سورەتی قورئانە و ٢٨٦ ئایەتی تێدایە.'
  },
  {
    id: 6,
    question: 'کورتترین سورەتی قورئان کامەیە؟',
    options: ['سورەتی کەوسەر', 'سورەتی ناس', 'سورەتی فەلەق', 'سورەتی ئیخلاس'],
    correctAnswer: 0,
    category: 'quran',
    difficulty: 'medium',
    explanation: 'سورەتی کەوسەر کورتترین سورەتی قورئانە و تەنها ٣ ئایەتی تێدایە.'
  },
  {
    id: 7,
    question: 'ئایەتی کورسی لە کام سورەتدایە؟',
    options: ['سورەتی ئالی عیمران', 'سورەتی بەقەرە', 'سورەتی نیسا', 'سورەتی مائیدە'],
    correctAnswer: 1,
    category: 'quran',
    difficulty: 'easy',
    explanation: 'ئایەتی کورسی ئایەتی ٢٥٥ی سورەتی بەقەرەیە.'
  },
  {
    id: 8,
    question: 'چەند جوز لە قورئاندا هەیە؟',
    options: ['٢٠ جوز', '٢٥ جوز', '٣٠ جوز', '٤٠ جوز'],
    correctAnswer: 2,
    category: 'quran',
    difficulty: 'easy',
    explanation: 'قورئان ٣٠ جوزی تێدایە.'
  },
  {
    id: 9,
    question: 'کام سورەت بە ناوی "عروسی قورئان" ناسراوە؟',
    options: ['سورەتی یاسین', 'سورەتی ڕەحمان', 'سورەتی مولک', 'سورەتی واقیعە'],
    correctAnswer: 1,
    category: 'quran',
    difficulty: 'hard',
    explanation: 'سورەتی ڕەحمان بە ناوی "عروسی قورئان" ناسراوە بەهۆی جوانی و نیعمەتەکان.'
  },
  {
    id: 10,
    question: 'کام سورەت بەبێ بەسمەڵا دەست پێدەکات؟',
    options: ['سورەتی بەقەرە', 'سورەتی فاتیحە', 'سورەتی تەوبە', 'سورەتی یاسین'],
    correctAnswer: 2,
    category: 'quran',
    difficulty: 'medium',
    explanation: 'سورەتی تەوبە تەنها سورەتەکەیە کە بەبێ بەسمەڵا دەست پێدەکات.'
  },
  {
    id: 11,
    question: 'چەند ئایەت لە قورئاندا هەیە؟',
    options: ['٦٢٣٦ ئایەت', '٦٣٤٨ ئایەت', '٦٥٠٠ ئایەت', '٧٠٠٠ ئایەت'],
    correctAnswer: 0,
    category: 'quran',
    difficulty: 'hard',
    explanation: 'قورئانی پیرۆز ٦٢٣٦ ئایەتی تێدایە بەپێی ڕۆژمێری کوفە.'
  },
  {
    id: 12,
    question: 'سورەتی ئیخلاس بەرامبەری چەند لە قورئانە؟',
    options: ['سێیەکی قورئان', 'نیوەی قورئان', 'دووسێیەکی قورئان', 'چارەکی قورئان'],
    correctAnswer: 0,
    category: 'quran',
    difficulty: 'medium',
    explanation: 'پێغەمبەر ﷺ فەرمووی سورەتی ئیخلاس بەرامبەری سێیەکی قورئانە.'
  },
  {
    id: 13,
    question: 'کام ئایەت بە "سەیدی ئایات" ناسراوە؟',
    options: ['ئایەتی کورسی', 'ئایەتی نوور', 'ئایەتی دەین', 'ئایەتی حیجاب'],
    correctAnswer: 0,
    category: 'quran',
    difficulty: 'medium',
    explanation: 'ئایەتی کورسی بە "سەیدی ئایات" (گەورەی ئایەتەکان) ناسراوە.'
  },
  {
    id: 14,
    question: 'قورئان لە چەند ساڵدا تەواو دابەزی؟',
    options: ['١٠ ساڵ', '٢٠ ساڵ', '٢٣ ساڵ', '٢٥ ساڵ'],
    correctAnswer: 2,
    category: 'quran',
    difficulty: 'easy',
    explanation: 'قورئان لە ماوەی ٢٣ ساڵدا تەواو دابەزی.'
  },
  {
    id: 15,
    question: 'یەکەم ئایەتی قورئان کامەیە کە دابەزی؟',
    options: ['"ئیقرەء بئسم رەببیکە"', '"بسم الله الرحمن الرحیم"', '"الحمد لله رب العالمین"', '"قل هو الله أحد"'],
    correctAnswer: 0,
    category: 'quran',
    difficulty: 'easy',
    explanation: 'یەکەم ئایەتەکان لە سورەتی عەلەق بوون: "ئیقرەء بئسمی رەببیکەلەزی خەلەق".'
  },
  {
    id: 16,
    question: 'درێژترین ئایەتی قورئان لە کام سورەتدایە؟',
    options: ['سورەتی بەقەرە', 'سورەتی نیسا', 'سورەتی مائیدە', 'سورەتی ئەنعام'],
    correctAnswer: 0,
    category: 'quran',
    difficulty: 'hard',
    explanation: 'درێژترین ئایەت ئایەتی دەینە (ئایەت ٢٨٢) لە سورەتی بەقەرە.'
  },
  {
    id: 17,
    question: 'کام سورەت دوو بەسمەڵای تێدایە؟',
    options: ['سورەتی فاتیحە', 'سورەتی نەمل', 'سورەتی تەوبە', 'سورەتی بەقەرە'],
    correctAnswer: 1,
    category: 'quran',
    difficulty: 'hard',
    explanation: 'سورەتی نەمل دوو بەسمەڵای تێدایە: یەکێک لە سەرەتاو یەکێک لە ناو نامەی سولەیمان.'
  },
  {
    id: 18,
    question: 'کام پێغەمبەر زیاتر ناوی لە قورئاندا هاتووە؟',
    options: ['ئیبراهیم', 'موسا', 'نوح', 'عیسا'],
    correctAnswer: 1,
    category: 'quran',
    difficulty: 'medium',
    explanation: 'موسا (ع) زیاتر لە هەموو پێغەمبەرەکان ناوی لە قورئاندا هاتووە (١٣٦ جار).'
  },
  {
    id: 19,
    question: 'کام سورەت بەناوی ژنێک ناونراوە؟',
    options: ['سورەتی فاتیر', 'سورەتی مەریەم', 'سورەتی نیسا', 'سورەتی مومتەحینە'],
    correctAnswer: 1,
    category: 'quran',
    difficulty: 'easy',
    explanation: 'سورەتی مەریەم بەناوی دایکی عیسا (ع) ناونراوە.'
  },
  {
    id: 20,
    question: 'کام سورەت بەتەنها بەناوی ئاژەڵێک ناونراوە؟',
    options: ['سورەتی فیل', 'سورەتی نەحل', 'سورەتی عەنکەبووت', 'هەموویان'],
    correctAnswer: 3,
    category: 'quran',
    difficulty: 'medium',
    explanation: 'چەندین سورەت بەناوی ئاژەڵ ناونراون: فیل، نەحل (مێش هەنگوین)، عەنکەبووت، و هتد.'
  },
  {
    id: 21,
    question: 'کام سورەت بە "المنجیە" ناسراوە؟',
    options: ['سورەتی یاسین', 'سورەتی مولک', 'سورەتی واقیعە', 'سورەتی کەهف'],
    correctAnswer: 1,
    category: 'quran',
    difficulty: 'hard',
    explanation: 'سورەتی مولک بە "المنجیە" ناسراوە چونکە لە عەزابی گۆڕ ڕزگاری دەکات.'
  },
  {
    id: 22,
    question: 'چەند سورەتی مەککی لە قورئاندا هەیە؟',
    options: ['٧٠ سورەت', '٨٦ سورەت', '٩٠ سورەت', '١٠٠ سورەت'],
    correctAnswer: 1,
    category: 'quran',
    difficulty: 'hard',
    explanation: '٨٦ سورەت مەککین و ٢٨ سورەت مەدەنین.'
  },
  {
    id: 23,
    question: 'سجدەی تیلاوەت چەند جار لە قورئاندا هەیە؟',
    options: ['١٠ جار', '١٤ جار', '١٥ جار', '٢٠ جار'],
    correctAnswer: 2,
    category: 'quran',
    difficulty: 'hard',
    explanation: 'سجدەی تیلاوەت ١٥ جار لە قورئاندا هەیە.'
  },
  {
    id: 24,
    question: 'کام سورەت "تەبارەکەلەزی" ناوی تریە؟',
    options: ['سورەتی فورقان', 'سورەتی مولک', 'سورەتی رەحمان', 'سورەتی واقیعە'],
    correctAnswer: 1,
    category: 'quran',
    difficulty: 'medium',
    explanation: 'سورەتی مولک بە "تەبارەکەلەزی" ناسراوە چونکە بەو وشەیە دەست پێدەکات.'
  },
  {
    id: 25,
    question: 'کام سورەت بە "ڕووحی قورئان" ناسراوە؟',
    options: ['سورەتی فاتیحە', 'سورەتی یاسین', 'سورەتی ڕەحمان', 'سورەتی ئیخلاس'],
    correctAnswer: 0,
    category: 'quran',
    difficulty: 'hard',
    explanation: 'سورەتی فاتیحە بە "ڕووحی قورئان" و "ئوممول کیتاب" ناسراوە.'
  },

  // Hadith Questions
  {
    id: 26,
    question: 'چەند کۆمەڵەی حەدیسی سەرەکی هەیە کە بەناوی "کوتوبی سیتە" ناسراون؟',
    options: ['٤ کتێب', '٥ کتێب', '٦ کتێب', '٧ کتێب'],
    correctAnswer: 2,
    category: 'hadith',
    difficulty: 'easy',
    explanation: 'کوتوبی سیتە ٦ کتێبی سەرەکی حەدیسن: بوخاری، موسلیم، ئەبو داود، تیرمیزی، نەسائی، و ئیبن ماجە.'
  },
  {
    id: 27,
    question: 'دروستترین کتێبی حەدیس کامەیە؟',
    options: ['صەحیحی موسلیم', 'صەحیحی بوخاری', 'سونەنی ئەبو داود', 'موسنەدی ئەحمەد'],
    correctAnswer: 1,
    category: 'hadith',
    difficulty: 'easy',
    explanation: 'صەحیحی بوخاری دروستترین کتێبی حەدیسە لەلای زانایان.'
  },
  {
    id: 28,
    question: 'ناوی تەواوی ئیمامی بوخاری چییە؟',
    options: ['محمد بن ئیسماعیل', 'ئەحمەد بن حەنبەل', 'مالیک بن ئەنەس', 'محمد بن ئیدریس'],
    correctAnswer: 0,
    category: 'hadith',
    difficulty: 'medium',
    explanation: 'ناوی تەواوی ئیمامی بوخاری: محمد بن ئیسماعیل بن ئیبراهیم البوخاری.'
  },
  {
    id: 29,
    question: 'چەند حەدیس لە صەحیحی بوخاریدا هەیە (بەبێ دووبارە)؟',
    options: ['٢٦٠٢ حەدیس', '٣٠٠٠ حەدیس', '٤٠٠٠ حەدیس', '٧٥٦٣ حەدیس'],
    correctAnswer: 0,
    category: 'hadith',
    difficulty: 'hard',
    explanation: 'صەحیحی بوخاری ٢٦٠٢ حەدیسی بەبێ دووبارەی تێدایە (٧٥٦٣ بە دووبارەکانەوە).'
  },
  {
    id: 30,
    question: 'یەکەم حەدیسی صەحیحی بوخاری چییە؟',
    options: ['حەدیسی نییەت', 'حەدیسی جبریل', 'حەدیسی میعراج', 'حەدیسی ڕەحمەت'],
    correctAnswer: 0,
    category: 'hadith',
    difficulty: 'medium',
    explanation: '"إنما الأعمال بالنیات" (تەنها کردەوەکان بە نییەتن) یەکەم حەدیسی بوخارییە.'
  },
  {
    id: 31,
    question: 'کێ زیاتر حەدیسی لە پێغەمبەر ﷺ گێڕاوەتەوە؟',
    options: ['عائیشە', 'ئەبوهورەیرە', 'ئیبن عوەمەر', 'ئەنەس بن مالیک'],
    correctAnswer: 1,
    category: 'hadith',
    difficulty: 'easy',
    explanation: 'ئەبوهورەیرە زیاتر لە ٥٠٠٠ حەدیسی گێڕاوەتەوە.'
  },
  {
    id: 32,
    question: 'حەدیسی "قودسی" چییە؟',
    options: ['حەدیسی قودسییە', 'وشەی خودایە بە زمانی پێغەمبەر ﷺ', 'حەدیسی دەربارەی قودسە', 'حەدیسی پیرۆزە'],
    correctAnswer: 1,
    category: 'hadith',
    difficulty: 'medium',
    explanation: 'حەدیسی قودسی وشەی خودایە کە پێغەمبەر ﷺ بە زمانی خۆی گێڕاویەتییەوە.'
  },
  {
    id: 33,
    question: 'حەدیسی "موتەواتیر" چییە؟',
    options: ['حەدیسی دروست', 'حەدیسی کە ژمارەیەکی زۆر گێڕاویانەتەوە', 'حەدیسی لاواز', 'حەدیسی جعلی'],
    correctAnswer: 1,
    category: 'hadith',
    difficulty: 'hard',
    explanation: 'حەدیسی موتەواتیر ئەو حەدیسەیە کە ژمارەیەکی زۆر کەس گێڕاویانەتەوە بەشێوەیەک درۆ ناکرێت.'
  },
  {
    id: 34,
    question: '"أربعین النووی" چەند حەدیسی تێدایە؟',
    options: ['٤٠ حەدیس', '٤٢ حەدیس', '٥٠ حەدیس', '١٠٠ حەدیس'],
    correctAnswer: 1,
    category: 'hadith',
    difficulty: 'medium',
    explanation: 'ئەربەعینی نەوەوی ٤٢ حەدیسی تێدایە سەرەڕای ناوەکەی.'
  },
  {
    id: 35,
    question: 'ئیمامی موسلیم لە کوێ لەدایک بووە؟',
    options: ['مەککە', 'مەدینە', 'نیسابور', 'بوخارا'],
    correctAnswer: 2,
    category: 'hadith',
    difficulty: 'hard',
    explanation: 'ئیمامی موسلیم لە نیسابور (لە ئێران) لەدایک بووە.'
  },
  {
    id: 36,
    question: 'سلسلەی زێڕین چییە؟',
    options: ['زنجیرەی گێڕانەوەی حەدیس', 'سلسلەی زێڕی ڕاستی', 'ناوی کتێبێکە', 'ناوی مزگەوتێکە'],
    correctAnswer: 0,
    category: 'hadith',
    difficulty: 'hard',
    explanation: 'سلسلەی زێڕین: مالیک لە نافیع لە ئیبن عومەر - باشترین سلسلەی گێڕانەوەی حەدیسە.'
  },
  {
    id: 37,
    question: 'حەدیسی "مەوزوع" چییە؟',
    options: ['حەدیسی دروست', 'حەدیسی لاواز', 'حەدیسی جعلی', 'حەدیسی مورسەل'],
    correctAnswer: 2,
    category: 'hadith',
    difficulty: 'medium',
    explanation: 'حەدیسی مەوزوع ئەو حەدیسەیە کە بە درۆ دروستکراوە و پێغەمبەر ﷺ نەیفەرموویە.'
  },
  {
    id: 38,
    question: '"عیلمی ئەلڕیجال" چییە؟',
    options: ['زانستی مێژوو', 'زانستی ناساندنی گێڕەرەوەکانی حەدیس', 'زانستی تەفسیر', 'زانستی فیقه'],
    correctAnswer: 1,
    category: 'hadith',
    difficulty: 'hard',
    explanation: 'عیلمی ئەلڕیجال زانستی ناساندن و پشکنینی گێڕەرەوەکانی حەدیسە.'
  },
  {
    id: 39,
    question: 'ئیمامی بوخاری لە کام ساڵدا لەدایک بووە؟',
    options: ['١٩٠ هـ', '١٩٤ هـ', '٢٠٠ هـ', '٢٥٦ هـ'],
    correctAnswer: 1,
    category: 'hadith',
    difficulty: 'hard',
    explanation: 'ئیمامی بوخاری لە ساڵی ١٩٤ هیجری لەدایک بوو و لە ساڵی ٢٥٦ هیجری کۆچی دوایی کرد.'
  },
  {
    id: 40,
    question: 'کام لەم هاوەڵانە زیاتر حەدیسی گێڕاوەتەوە لە ژنان؟',
    options: ['خەدیجە', 'عائیشە', 'فاتیمە', 'حەفسە'],
    correctAnswer: 1,
    category: 'hadith',
    difficulty: 'easy',
    explanation: 'عائیشە زیاتر لە ٢٠٠٠ حەدیسی گێڕاوەتەوە، زیاتر لە هەموو ژنەکانی تر.'
  },
  {
    id: 41,
    question: 'حەدیسی "حەسەن" چییە؟',
    options: ['حەدیسی تەواو دروست', 'حەدیسی نێوان دروست و لاواز', 'حەدیسی لاواز', 'حەدیسی جعلی'],
    correctAnswer: 1,
    category: 'hadith',
    difficulty: 'medium',
    explanation: 'حەدیسی حەسەن ئەو حەدیسەیە کە مەرجەکانی دروستی هەیە بەڵام لە صەحیح کەمترە.'
  },
  {
    id: 42,
    question: 'کێ یەکەم کەس بوو حەدیسی کۆکردەوە؟',
    options: ['ئیمامی بوخاری', 'ئیمامی مالیک', 'ئیبن شیهاب ئەلزوهری', 'عومەر بن عەبدولعەزیز'],
    correctAnswer: 2,
    category: 'hadith',
    difficulty: 'hard',
    explanation: 'ئیبن شیهاب ئەلزوهری بەفەرمانی عومەر بن عەبدولعەزیز یەکەم کەس بوو حەدیسی کۆکردەوە.'
  },
  {
    id: 43,
    question: '"ئەلموؤتەلەف وەلموختەلەف" چییە؟',
    options: ['کتێبی حەدیس', 'زانستی ناوەکانی ئاوەته یەک دەچن بەڵام جیاوازن', 'کتێبی تەفسیر', 'کتێبی فیقه'],
    correctAnswer: 1,
    category: 'hadith',
    difficulty: 'hard',
    explanation: 'ئەلموؤتەلەف وەلموختەلەف زانستی ناوەکانی وەکیەکن بەڵام مەبەستیان جیاوازە.'
  },
  {
    id: 44,
    question: 'حەدیسی "مەرفوع" چییە؟',
    options: ['حەدیس لە هاوەڵ', 'حەدیس لە تابیعین', 'حەدیس لە پێغەمبەر ﷺ ڕاستەوخۆ', 'حەدیس لە کتێب'],
    correctAnswer: 2,
    category: 'hadith',
    difficulty: 'medium',
    explanation: 'حەدیسی مەرفوع ئەو حەدیسەیە کە بە پێغەمبەر ﷺ دەگاتەوە ڕاستەوخۆ.'
  },
  {
    id: 45,
    question: 'چەند ساڵ ئیمامی بوخاری کاری کرد بۆ صەحیحەکەی؟',
    options: ['١٠ ساڵ', '١٦ ساڵ', '٢٠ ساڵ', '٣٠ ساڵ'],
    correctAnswer: 1,
    category: 'hadith',
    difficulty: 'hard',
    explanation: 'ئیمامی بوخاری ١٦ ساڵی تەواوی خەرج کرد بۆ نووسینی صەحیحەکەی.'
  },
  {
    id: 46,
    question: '"ئەلجەرح وەلتەعدیل" چییە؟',
    options: ['زانستی قورئان', 'زانستی ناساندنی متمانەپێکراوی گێڕەرەوەکان', 'زانستی فیقه', 'زانستی تەفسیر'],
    correctAnswer: 1,
    category: 'hadith',
    difficulty: 'hard',
    explanation: 'ئەلجەرح وەلتەعدیل زانستی ناساندنی متمانەپێکراوی یان نامتمانەپێکراوی گێڕەرەوەکانە.'
  },
  {
    id: 47,
    question: 'حەدیسی "موعەللەق" چییە؟',
    options: ['حەدیسی کە سلسلەی تێدا ناتەواوە', 'حەدیسی دروست', 'حەدیسی لاواز', 'حەدیسی موتەواتیر'],
    correctAnswer: 0,
    category: 'hadith',
    difficulty: 'hard',
    explanation: 'حەدیسی موعەللەق ئەو حەدیسەیە کە لە سەرەتای سلسلەی یەک یان زیاتر لەگێڕەرەوەکان نییە.'
  },
  {
    id: 48,
    question: 'سونەنی ئەربەعە کامانەن؟',
    options: ['بوخاری، موسلیم، تیرمیزی، نەسائی', 'ئەبو داود، تیرمیزی، نەسائی، ئیبن ماجە', 'مالیک، شافعی، ئەحمەد، حەنبەلی', 'موتەواتیر، صەحیح، حەسەن، ضەعیف'],
    correctAnswer: 1,
    category: 'hadith',
    difficulty: 'medium',
    explanation: 'سونەنی ئەربەعە: سونەنی ئەبو داود، سونەنی تیرمیزی، سونەنی نەسائی، سونەنی ئیبن ماجە.'
  },
  {
    id: 49,
    question: '"موسنەد" چییە؟',
    options: ['کتێبی حەدیس بەپێی سلسلەکانی هاوەڵان', 'کتێبی قورئان', 'کتێبی تەفسیر', 'کتێبی فیقه'],
    correctAnswer: 0,
    category: 'hadith',
    difficulty: 'medium',
    explanation: 'موسنەد کتێبی حەدیسە کە حەدیسەکان بەپێی سلسلەکانی هاوەڵان ڕێکخراون.'
  },
  {
    id: 50,
    question: 'زۆرترین موسنەد کامەیە؟',
    options: ['موسنەدی مالیک', 'موسنەدی ئەحمەد بن حەنبەل', 'موسنەدی شافعی', 'موسنەدی ئەبو حەنیفە'],
    correctAnswer: 1,
    category: 'hadith',
    difficulty: 'medium',
    explanation: 'موسنەدی ئیمامی ئەحمەد بن حەنبەل زۆرترین موسنەدە و نزیکەی ٣٠,٠٠٠ حەدیسی تێدایە.'
  },

  // Prophet Questions
  {
    id: 51,
    question: 'پێغەمبەر ﷺ لە کام ساڵدا لەدایک بووە؟',
    options: ['ساڵی فیل (٥٧٠ز)', 'ساڵی ٥٨٠ز', 'ساڵی ٥٩٠ز', 'ساڵی ٦٠٠ز'],
    correctAnswer: 0,
    category: 'prophet',
    difficulty: 'easy',
    explanation: 'پێغەمبەر ﷺ لە ساڵی فیل (٥٧٠ز) لە مەککەدا لەدایک بووە.'
  },
  {
    id: 52,
    question: 'ناوی باوکی پێغەمبەر ﷺ چییە؟',
    options: ['ئەبوتالیب', 'عەبدوڵا', 'عەبدولموتەڵیب', 'هاشیم'],
    correctAnswer: 1,
    category: 'prophet',
    difficulty: 'easy',
    explanation: 'ناوی باوکی پێغەمبەر ﷺ عەبدوڵا بن عەبدولموتەڵیب بوو.'
  },
  {
    id: 53,
    question: 'ناوی دایکی پێغەمبەر ﷺ چییە؟',
    options: ['خەدیجە', 'ئامینە', 'فاتیمە', 'عائیشە'],
    correctAnswer: 1,
    category: 'prophet',
    difficulty: 'easy',
    explanation: 'ناوی دایکی پێغەمبەر ﷺ ئامینە بنت وەهەب بوو.'
  },
  {
    id: 54,
    question: 'کێ شیری پێغەمبەر ﷺ ی داوە لە منداڵیدا؟',
    options: ['ئامینە', 'حەلیمەی سەعدیە', 'خەدیجە', 'ئومم ئەیمەن'],
    correctAnswer: 1,
    category: 'prophet',
    difficulty: 'easy',
    explanation: 'حەلیمەی سەعدیە لە هۆزی بەنی سەعد شیری پێغەمبەر ﷺ داوە.'
  },
  {
    id: 55,
    question: 'پێغەمبەر ﷺ لە چەند تەمەنیدا پێغەمبەرایەتی پێ درا؟',
    options: ['٣٠ ساڵی', '٣٥ ساڵی', '٤٠ ساڵی', '٤٥ ساڵی'],
    correctAnswer: 2,
    category: 'prophet',
    difficulty: 'easy',
    explanation: 'پێغەمبەر ﷺ لە تەمەنی ٤٠ ساڵیدا پێغەمبەرایەتی پێ درا.'
  },
  {
    id: 56,
    question: 'یەکەم هاوسەری پێغەمبەر ﷺ کێ بوو؟',
    options: ['عائیشە', 'سەودە', 'خەدیجە', 'حەفسە'],
    correctAnswer: 2,
    category: 'prophet',
    difficulty: 'easy',
    explanation: 'خەدیجە بنت خوەیلید یەکەم هاوسەری پێغەمبەر ﷺ بوو.'
  },
  {
    id: 57,
    question: 'پێغەمبەر ﷺ لە کوێ کۆچی دوایی کردووە؟',
    options: ['مەککە', 'مەدینە', 'قودس', 'تائیف'],
    correctAnswer: 1,
    category: 'prophet',
    difficulty: 'easy',
    explanation: 'پێغەمبەر ﷺ لە مەدینەی منەوەرەدا کۆچی دوایی کردووە.'
  },
  {
    id: 58,
    question: 'گۆڕی پێغەمبەر ﷺ لە کوێیە؟',
    options: ['مزگەوتی حەرام', 'مزگەوتی نەبەوی', 'مزگەوتی ئەقسا', 'مزگەوتی قوبا'],
    correctAnswer: 1,
    category: 'prophet',
    difficulty: 'easy',
    explanation: 'گۆڕی پێغەمبەر ﷺ لە مزگەوتی نەبەوی لە مەدینەیە.'
  },
  {
    id: 59,
    question: 'یەکەم موسڵمانی پیاو کێ بوو؟',
    options: ['ئەبوبەکر', 'عەلی', 'عوسمان', 'عومەر'],
    correctAnswer: 0,
    category: 'prophet',
    difficulty: 'medium',
    explanation: 'ئەبوبەکر سدیق یەکەم موسڵمانی پیاو بوو لە موسڵمانانی گەورە.'
  },
  {
    id: 60,
    question: 'یەکەم موسڵمانی ژن کێ بوو؟',
    options: ['عائیشە', 'فاتیمە', 'خەدیجە', 'ئومم سەلەمە'],
    correctAnswer: 2,
    category: 'prophet',
    difficulty: 'easy',
    explanation: 'خەدیجە یەکەم موسڵمانی ژن و یەکەم موسڵمان بە گشتی بوو.'
  },
  {
    id: 61,
    question: 'شەڕی بەدر لە کام ساڵدا ڕووی دا؟',
    options: ['١ هیجری', '٢ هیجری', '٣ هیجری', '٤ هیجری'],
    correctAnswer: 1,
    category: 'prophet',
    difficulty: 'medium',
    explanation: 'شەڕی بەدر لە ساڵی ٢ هیجریدا ڕووی دا (٦٢٤ز).'
  },
  {
    id: 62,
    question: 'شەڕی ئوحود لە کام ساڵدا ڕووی دا؟',
    options: ['٢ هیجری', '٣ هیجری', '٤ هیجری', '٥ هیجری'],
    correctAnswer: 1,
    category: 'prophet',
    difficulty: 'medium',
    explanation: 'شەڕی ئوحود لە ساڵی ٣ هیجریدا ڕووی دا (٦٢٥ز).'
  },
  {
    id: 63,
    question: 'کێ یارمەتیدەری پێغەمبەر ﷺ بوو لە کۆچکردندا؟',
    options: ['عومەر', 'عەلی', 'ئەبوبەکر', 'عوسمان'],
    correctAnswer: 2,
    category: 'prophet',
    difficulty: 'easy',
    explanation: 'ئەبوبەکر سدیق لەگەڵ پێغەمبەر ﷺ کۆچی کرد بۆ مەدینە.'
  },
  {
    id: 64,
    question: 'پێغەمبەر ﷺ لە کام غاردا شاران لە کاتی کۆچکردندا؟',
    options: ['غاری حیرا', 'غاری سەور', 'غاری ئوحود', 'غاری بەدر'],
    correctAnswer: 1,
    category: 'prophet',
    difficulty: 'medium',
    explanation: 'پێغەمبەر ﷺ و ئەبوبەکر لە غاری سەور شاران بۆ سێ شەو.'
  },
  {
    id: 65,
    question: 'کۆچکردنی پێغەمبەر ﷺ لە کام ساڵدا بوو؟',
    options: ['٦٢٠ز', '٦٢١ز', '٦٢٢ز', '٦٢٣ز'],
    correctAnswer: 2,
    category: 'prophet',
    difficulty: 'easy',
    explanation: 'کۆچکردنی پێغەمبەر ﷺ لە ساڵی ٦٢٢زدا بوو.'
  },
  {
    id: 66,
    question: 'چەند کوڕی پێغەمبەر ﷺ هەبوو؟',
    options: ['٢ کوڕ', '٣ کوڕ', '٤ کوڕ', '٥ کوڕ'],
    correctAnswer: 1,
    category: 'prophet',
    difficulty: 'medium',
    explanation: 'پێغەمبەر ﷺ سێ کوڕی هەبوو: قاسیم، عەبدوڵا، و ئیبراهیم.'
  },
  {
    id: 67,
    question: 'چەند کچی پێغەمبەر ﷺ هەبوو؟',
    options: ['٢ کچ', '٣ کچ', '٤ کچ', '٥ کچ'],
    correctAnswer: 2,
    category: 'prophet',
    difficulty: 'medium',
    explanation: 'پێغەمبەر ﷺ چوار کچی هەبوو: زەینەب، ڕوقەییە، ئومم کولسوم، و فاتیمە.'
  },
  {
    id: 68,
    question: 'کێ یەکەم خەلیفە بوو دوای پێغەمبەر ﷺ؟',
    options: ['عومەر', 'عەلی', 'ئەبوبەکر', 'عوسمان'],
    correctAnswer: 2,
    category: 'prophet',
    difficulty: 'easy',
    explanation: 'ئەبوبەکر سدیق یەکەم خەلیفەی ڕاشد بوو.'
  },
  {
    id: 69,
    question: 'پێغەمبەر ﷺ لە چەند تەمەنیدا کۆچی دوایی کرد؟',
    options: ['٥٥ ساڵی', '٦٠ ساڵی', '٦٣ ساڵی', '٧٠ ساڵی'],
    correctAnswer: 2,
    category: 'prophet',
    difficulty: 'easy',
    explanation: 'پێغەمبەر ﷺ لە تەمەنی ٦٣ ساڵیدا کۆچی دوایی کرد.'
  },
  {
    id: 70,
    question: 'کردنەوەی مەککە لە کام ساڵدا بوو؟',
    options: ['٦ هیجری', '٧ هیجری', '٨ هیجری', '٩ هیجری'],
    correctAnswer: 2,
    category: 'prophet',
    difficulty: 'medium',
    explanation: 'کردنەوەی مەککە لە ساڵی ٨ هیجریدا بوو (٦٣٠ز).'
  },
  {
    id: 71,
    question: 'ڕێکەوتنی حودەیبیە لە کام ساڵدا بوو؟',
    options: ['٤ هیجری', '٥ هیجری', '٦ هیجری', '٧ هیجری'],
    correctAnswer: 2,
    category: 'prophet',
    difficulty: 'hard',
    explanation: 'ڕێکەوتنی حودەیبیە لە ساڵی ٦ هیجریدا بوو.'
  },
  {
    id: 72,
    question: 'مامی پێغەمبەر ﷺ کە بەخێوی کردبوو کێ بوو؟',
    options: ['حەمزە', 'عەبباس', 'ئەبوتالیب', 'ئەبولەهەب'],
    correctAnswer: 2,
    category: 'prophet',
    difficulty: 'easy',
    explanation: 'ئەبوتالیب مامی پێغەمبەر ﷺ بەخێوی کردبوو دوای مردنی باپیری.'
  },
  {
    id: 73,
    question: 'کام فریشتە وەحیی بۆ پێغەمبەر ﷺ دەهێنا؟',
    options: ['میکائیل', 'ئیسرافیل', 'جبرائیل', 'عزرائیل'],
    correctAnswer: 2,
    category: 'prophet',
    difficulty: 'easy',
    explanation: 'جبرائیل (ع) فریشتەی وەحی بوو و قورئانی بۆ پێغەمبەر ﷺ دەهێنا.'
  },
  {
    id: 74,
    question: 'حەجی ماڵئاوایی لە کام ساڵدا بوو؟',
    options: ['٨ هیجری', '٩ هیجری', '١٠ هیجری', '١١ هیجری'],
    correctAnswer: 2,
    category: 'prophet',
    difficulty: 'medium',
    explanation: 'حەجی ماڵئاوایی لە ساڵی ١٠ هیجریدا بوو.'
  },
  {
    id: 75,
    question: 'پێغەمبەر ﷺ بەناوی چی ناسرا بوو پێش پێغەمبەرایەتی؟',
    options: ['الصادق الأمین', 'الحبیب', 'المختار', 'الهادی'],
    correctAnswer: 0,
    category: 'prophet',
    difficulty: 'easy',
    explanation: 'پێغەمبەر ﷺ بەناوی "الصادق الأمین" (ڕاستگۆ و متمانەپێکراو) ناسرا بوو.'
  },

  // Fiqh Questions
  {
    id: 76,
    question: 'ستوونەکانی ئیسلام چەندن؟',
    options: ['٣ ستوون', '٤ ستوون', '٥ ستوون', '٦ ستوون'],
    correctAnswer: 2,
    category: 'fiqh',
    difficulty: 'easy',
    explanation: 'ستوونەکانی ئیسلام ٥ن: شەهادە، نوێژ، زەکات، ڕۆژوو، و حەج.'
  },
  {
    id: 77,
    question: 'چەند نوێژ لە ڕۆژێکدا فەرزە؟',
    options: ['٣ نوێژ', '٤ نوێژ', '٥ نوێژ', '٧ نوێژ'],
    correctAnswer: 2,
    category: 'fiqh',
    difficulty: 'easy',
    explanation: '٥ نوێژ لە ڕۆژێکدا فەرزە: بەیانی، نیوەڕۆ، عەسر، شێوان، و خەوتن.'
  },
  {
    id: 78,
    question: 'نوێژی بەیانی چەند ڕکاتە؟',
    options: ['٢ ڕکات', '٣ ڕکات', '٤ ڕکات', '٥ ڕکات'],
    correctAnswer: 0,
    category: 'fiqh',
    difficulty: 'easy',
    explanation: 'نوێژی بەیانی ٢ ڕکاتە.'
  },
  {
    id: 79,
    question: 'نوێژی نیوەڕۆ چەند ڕکاتە؟',
    options: ['٢ ڕکات', '٣ ڕکات', '٤ ڕکات', '٥ ڕکات'],
    correctAnswer: 2,
    category: 'fiqh',
    difficulty: 'easy',
    explanation: 'نوێژی نیوەڕۆ ٤ ڕکاتە.'
  },
  {
    id: 80,
    question: 'نوێژی مەغریب چەند ڕکاتە؟',
    options: ['٢ ڕکات', '٣ ڕکات', '٤ ڕکات', '٥ ڕکات'],
    correctAnswer: 1,
    category: 'fiqh',
    difficulty: 'easy',
    explanation: 'نوێژی مەغریب ٣ ڕکاتە.'
  },
  {
    id: 81,
    question: 'ڕۆژووی مانگی ڕەمەزان چەند ڕۆژە؟',
    options: ['٢٨ یان ٢٩ ڕۆژ', '٢٩ یان ٣٠ ڕۆژ', '٣٠ یان ٣١ ڕۆژ', '٣١ یان ٣٢ ڕۆژ'],
    correctAnswer: 1,
    category: 'fiqh',
    difficulty: 'easy',
    explanation: 'ڕۆژووی ڕەمەزان ٢٩ یان ٣٠ ڕۆژە بەپێی مانگ.'
  },
  {
    id: 82,
    question: 'زەکات لە چەند جۆر سامانەوە واجبە؟',
    options: ['٣ جۆر', '٤ جۆر', '٥ جۆر', '٨ جۆر'],
    correctAnswer: 3,
    category: 'fiqh',
    difficulty: 'medium',
    explanation: 'زەکات لە ٨ جۆر سامانەوە واجبە کە لە قورئاندا باسکراون.'
  },
  {
    id: 83,
    question: 'نیسابی زێڕ بۆ زەکات چەندە؟',
    options: ['٧٠ گرام', '٨٥ گرام', '١٠٠ گرام', '١٢٠ گرام'],
    correctAnswer: 1,
    category: 'fiqh',
    difficulty: 'hard',
    explanation: 'نیسابی زێڕ بۆ زەکات ٨٥ گرام زێڕە (٢٠ میسقال).'
  },
  {
    id: 84,
    question: 'ڕێژەی زەکاتی پارە چەندە؟',
    options: ['١٪', '٢.٥٪', '٥٪', '١٠٪'],
    correctAnswer: 1,
    category: 'fiqh',
    difficulty: 'easy',
    explanation: 'ڕێژەی زەکاتی پارە ٢.٥٪ یە (رُبع العُشر).'
  },
  {
    id: 85,
    question: 'حەج لە کام مانگدا واجبە؟',
    options: ['ڕەجەب', 'شەعبان', 'ڕەمەزان', 'زولحیجە'],
    correctAnswer: 3,
    category: 'fiqh',
    difficulty: 'easy',
    explanation: 'حەج لە مانگی زولحیجەدا واجبە.'
  },
  {
    id: 86,
    question: 'چەند ڕوکنی حەج هەیە؟',
    options: ['٣ ڕوکن', '٤ ڕوکن', '٥ ڕوکن', '٦ ڕوکن'],
    correctAnswer: 1,
    category: 'fiqh',
    difficulty: 'medium',
    explanation: 'حەج ٤ ڕوکنی هەیە: ئیحرام، وەستان لە عەرەفات، تەوافی زیارەت، و سەعی.'
  },
  {
    id: 87,
    question: 'شەرتەکانی وەزوو چەندن؟',
    options: ['٤ شەرت', '٦ شەرت', '٨ شەرت', '١٠ شەرت'],
    correctAnswer: 2,
    category: 'fiqh',
    difficulty: 'medium',
    explanation: 'شەرتەکانی وەزوو ٨ن: ئیسلام، عاقلی، تەمیز، نییەت، ئاو پاک، ڕواندنی گیرگر، و هتد.'
  },
  {
    id: 88,
    question: 'فەرزەکانی وەزوو چەندن؟',
    options: ['٤ فەرز', '٦ فەرز', '٨ فەرز', '١٠ فەرز'],
    correctAnswer: 1,
    category: 'fiqh',
    difficulty: 'medium',
    explanation: 'فەرزەکانی وەزوو ٦ن: شوشتنی ڕوو، شوشتنی دەست، مەسح سەر، شوشتنی پێ، ڕێکخستن، و بەردەوامی.'
  },
  {
    id: 89,
    question: 'شکێنەرەکانی وەزوو چەندن؟',
    options: ['٤', '٦', '٨', '١٠'],
    correctAnswer: 1,
    category: 'fiqh',
    difficulty: 'medium',
    explanation: 'شکێنەرەکانی وەزوو ٦ن: دەرچوونی شت لە پێش و پاشەوە، نەبوونی هۆش، دەست لێدانی تاوانبار، و هتد.'
  },
  {
    id: 90,
    question: 'نوێژی جومعە چەند ڕکاتە؟',
    options: ['٢ ڕکات', '٣ ڕکات', '٤ ڕکات', '٦ ڕکات'],
    correctAnswer: 0,
    category: 'fiqh',
    difficulty: 'easy',
    explanation: 'نوێژی جومعە ٢ ڕکاتە لەدوای وتاری خوتبە.'
  },
  {
    id: 91,
    question: 'نوێژی عیدی فیتر و قوربان چەند ڕکاتە؟',
    options: ['٢ ڕکات', '٣ ڕکات', '٤ ڕکات', '٦ ڕکات'],
    correctAnswer: 0,
    category: 'fiqh',
    difficulty: 'easy',
    explanation: 'نوێژی عید ٢ ڕکاتە.'
  },
  {
    id: 92,
    question: 'تەیەمموم کەی ڕێگەپێدراوە؟',
    options: ['هەمیشە', 'کاتی نەبوونی ئاو یان نەتوانینی بەکارهێنانی', 'هەرگیز', 'تەنها لە سەفەردا'],
    correctAnswer: 1,
    category: 'fiqh',
    difficulty: 'medium',
    explanation: 'تەیەمموم ڕێگەپێدراوە کاتی نەبوونی ئاو یان نەتوانینی بەکارهێنانی بەهۆی نەخۆشی.'
  },
  {
    id: 93,
    question: 'کورتکردنەوەی نوێژ لە سەفەردا بۆ کام نوێژە؟',
    options: ['هەموو نوێژەکان', 'نوێژی ٤ ڕکاتی', 'نوێژی بەیانی تەنها', 'نوێژی مەغریب تەنها'],
    correctAnswer: 1,
    category: 'fiqh',
    difficulty: 'medium',
    explanation: 'کورتکردنەوەی نوێژ تەنها بۆ نوێژی ٤ ڕکاتییە (نیوەڕۆ، عەسر، خەوتن) دەبێتە ٢ ڕکات.'
  },
  {
    id: 94,
    question: 'زەکاتی فیتر کەی دەردەکرێت؟',
    options: ['پێش ڕەمەزان', 'لە کۆتایی ڕەمەزان پێش نوێژی عید', 'لەدوای عید', 'لە ناوەڕاستی ڕەمەزان'],
    correctAnswer: 1,
    category: 'fiqh',
    difficulty: 'easy',
    explanation: 'زەکاتی فیتر پێش نوێژی عیدی فیتر دەردەکرێت.'
  },
  {
    id: 95,
    question: 'سوننەتی ڕەواتیب چەندن لە ڕۆژێکدا؟',
    options: ['٨ ڕکات', '١٠ ڕکات', '١٢ ڕکات', '١٤ ڕکات'],
    correctAnswer: 2,
    category: 'fiqh',
    difficulty: 'medium',
    explanation: 'سوننەتی ڕەواتیب ١٢ ڕکاتە: ٢ پێش بەیانی، ٤ پێش نیوەڕۆ و ٢ دواتر، ٢ دوای مەغریب، ٢ دوای عیشا.'
  },
  {
    id: 96,
    question: 'نوێژی تەراویح چەند ڕکاتە؟',
    options: ['٨ ڕکات', '١٠ ڕکات', '٢٠ ڕکات', '٨ یان ٢٠'],
    correctAnswer: 3,
    category: 'fiqh',
    difficulty: 'medium',
    explanation: 'نوێژی تەراویح ٨ یان ٢٠ ڕکاتە بەپێی مەزهەبەکان.'
  },
  {
    id: 97,
    question: 'عومرە چەند ڕوکنی هەیە؟',
    options: ['٢ ڕوکن', '٣ ڕوکن', '٤ ڕوکن', '٥ ڕوکن'],
    correctAnswer: 1,
    category: 'fiqh',
    difficulty: 'hard',
    explanation: 'عومرە ٣ ڕوکنی هەیە: ئیحرام، تەواف، و سەعی.'
  },
  {
    id: 98,
    question: 'چەند مەزهەبی سەرەکی سوننی هەیە؟',
    options: ['٢ مەزهەب', '٣ مەزهەب', '٤ مەزهەب', '٥ مەزهەب'],
    correctAnswer: 2,
    category: 'fiqh',
    difficulty: 'easy',
    explanation: '٤ مەزهەبی سەرەکی سوننی هەیە: حەنەفی، مالیکی، شافعی، و حەنبەلی.'
  },
  {
    id: 99,
    question: 'نوێژی کوسوف بۆ چییە؟',
    options: ['گرتنی خۆر', 'گرتنی مانگ', 'بارانخوازی', 'شوکری نیعمەت'],
    correctAnswer: 0,
    category: 'fiqh',
    difficulty: 'medium',
    explanation: 'نوێژی کوسوف بۆ گرتنی خۆرە و نوێژی خوسوف بۆ گرتنی مانگە.'
  },
  {
    id: 100,
    question: 'نوێژی ئیستیسقا بۆ چییە؟',
    options: ['گرتنی خۆر', 'گرتنی مانگ', 'داواکردنی باران', 'شوکری نیعمەت'],
    correctAnswer: 2,
    category: 'fiqh',
    difficulty: 'medium',
    explanation: 'نوێژی ئیستیسقا نوێژی داواکردنی بارانە لە خودا.'
  },

  // General Questions
  {
    id: 101,
    question: 'ستوونەکانی ئیمان چەندن؟',
    options: ['٤ ستوون', '٥ ستوون', '٦ ستوون', '٧ ستوون'],
    correctAnswer: 2,
    category: 'general',
    difficulty: 'easy',
    explanation: 'ستوونەکانی ئیمان ٦ن: باوەڕ بە خودا، فریشتەکان، کتێبەکان، پێغەمبەرەکان، ڕۆژی دوایی، و چارەنووس.'
  },
  {
    id: 102,
    question: 'چەند کتێبی ئاسمانی بە پێغەمبەرەکان نازڵ کراوە؟',
    options: ['٢ کتێب', '٣ کتێب', '٤ کتێب', '٥ کتێب'],
    correctAnswer: 2,
    category: 'general',
    difficulty: 'easy',
    explanation: '٤ کتێبی ئاسمانی: تەورات، زەبوور، ئینجیل، و قورئان.'
  },
  {
    id: 103,
    question: 'چەند ناوی خودا لە ناوە جوانەکاندا هەیە؟',
    options: ['٧٧ ناو', '٨٨ ناو', '٩٩ ناو', '١٠٠ ناو'],
    correctAnswer: 2,
    category: 'general',
    difficulty: 'easy',
    explanation: '٩٩ ناوی جوانی خودا هەیە کە بەناوی "ئەسماء الحسنی" ناسراون.'
  },
  {
    id: 104,
    question: 'چەند پێغەمبەر ناویان لە قورئاندا هاتووە؟',
    options: ['٢٠ پێغەمبەر', '٢٥ پێغەمبەر', '٣٠ پێغەمبەر', '٣٥ پێغەمبەر'],
    correctAnswer: 1,
    category: 'general',
    difficulty: 'medium',
    explanation: '٢٥ پێغەمبەر ناویان لە قورئاندا هاتووە.'
  },
  {
    id: 105,
    question: 'یەکەم پێغەمبەر کێ بوو؟',
    options: ['نوح', 'ئیبراهیم', 'ئادەم', 'موسا'],
    correctAnswer: 2,
    category: 'general',
    difficulty: 'easy',
    explanation: 'ئادەم (ع) یەکەم پێغەمبەر و یەکەم مرۆڤ بوو.'
  },
  {
    id: 106,
    question: 'کۆتا پێغەمبەر کێ بوو؟',
    options: ['عیسا', 'موسا', 'محمد ﷺ', 'ئیبراهیم'],
    correctAnswer: 2,
    category: 'general',
    difficulty: 'easy',
    explanation: 'محمد ﷺ کۆتا پێغەمبەر بوو (خاتەم النبیین).'
  },
  {
    id: 107,
    question: 'کام پێغەمبەر بە "خەلیل الله" ناسراوە؟',
    options: ['موسا', 'عیسا', 'ئیبراهیم', 'نوح'],
    correctAnswer: 2,
    category: 'general',
    difficulty: 'easy',
    explanation: 'ئیبراهیم (ع) بە "خەلیل الله" (هاوڕێی خودا) ناسراوە.'
  },
  {
    id: 108,
    question: 'کام پێغەمبەر بە "کەلیم الله" ناسراوە؟',
    options: ['ئیبراهیم', 'موسا', 'عیسا', 'نوح'],
    correctAnswer: 1,
    category: 'general',
    difficulty: 'easy',
    explanation: 'موسا (ع) بە "کەلیم الله" (ئەوەی خودا قسەی لەگەڵ کرد) ناسراوە.'
  },
  {
    id: 109,
    question: 'کام پێغەمبەر بە "ڕووح الله" ناسراوە؟',
    options: ['ئیبراهیم', 'موسا', 'عیسا', 'ئادەم'],
    correctAnswer: 2,
    category: 'general',
    difficulty: 'easy',
    explanation: 'عیسا (ع) بە "ڕووح الله" و "کەلیمەی خودا" ناسراوە.'
  },
  {
    id: 110,
    question: 'چەند فریشتەی سەرەکی هەیە؟',
    options: ['٢ فریشتە', '٣ فریشتە', '٤ فریشتە', '٥ فریشتە'],
    correctAnswer: 2,
    category: 'general',
    difficulty: 'easy',
    explanation: '٤ فریشتەی سەرەکی: جبرائیل، میکائیل، ئیسرافیل، و عزرائیل.'
  },
  {
    id: 111,
    question: 'کام فریشتە بەرپرسی بارانە؟',
    options: ['جبرائیل', 'میکائیل', 'ئیسرافیل', 'عزرائیل'],
    correctAnswer: 1,
    category: 'general',
    difficulty: 'medium',
    explanation: 'میکائیل (ع) بەرپرسی باران و ڕزقە.'
  },
  {
    id: 112,
    question: 'کام فریشتە سووری دەفوکێت لە ڕۆژی دوایی؟',
    options: ['جبرائیل', 'میکائیل', 'ئیسرافیل', 'عزرائیل'],
    correctAnswer: 2,
    category: 'general',
    difficulty: 'medium',
    explanation: 'ئیسرافیل (ع) سووری دەفوکێت بۆ ڕۆژی قیامەت.'
  },
  {
    id: 113,
    question: 'کێوی عەرەفات لە کوێیە؟',
    options: ['مەککە', 'مەدینە', 'نزیکی مەککە', 'قودس'],
    correctAnswer: 2,
    category: 'general',
    difficulty: 'easy',
    explanation: 'کێوی عەرەفات نزیکی مەککەیە و شوێنی وەستانی سەرەکی حەجە.'
  },
  {
    id: 114,
    question: 'بەردی ڕەشی کەعبە لە کوێیە؟',
    options: ['ناوەوەی کەعبە', 'گۆشەی ڕۆژهەڵات', 'گۆشەی ڕۆژئاوا', 'سەرەوەی کەعبە'],
    correctAnswer: 1,
    category: 'general',
    difficulty: 'medium',
    explanation: 'بەردی ڕەش لە گۆشەی ڕۆژهەڵاتی کەعبەیە.'
  },
  {
    id: 115,
    question: 'مەقامی ئیبراهیم چییە؟',
    options: ['شوێنی گۆڕی ئیبراهیم', 'شوێنی پێی ئیبراهیم', 'خانووی ئیبراهیم', 'مزگەوتی ئیبراهیم'],
    correctAnswer: 1,
    category: 'general',
    difficulty: 'medium',
    explanation: 'مەقامی ئیبراهیم بەردێکە کە شوێنی پێی ئیبراهیم (ع) تێدایە لەکاتی بنیادنانی کەعبە.'
  },
  {
    id: 116,
    question: 'زەمزەم چییە؟',
    options: ['کانیاوێکە نزیکی کەعبە', 'ناوی کێوێکە', 'ناوی دەروازەیەکە', 'ناوی مزگەوتێکە'],
    correctAnswer: 0,
    category: 'general',
    difficulty: 'easy',
    explanation: 'زەمزەم کانیاوێکی بەرەکەتدارە نزیکی کەعبە.'
  },
  {
    id: 117,
    question: 'سەفا و مەروە چین؟',
    options: ['دوو کێون', 'دوو گیرفان', 'دوو مزگەوت', 'دوو کانیاو'],
    correctAnswer: 1,
    category: 'general',
    difficulty: 'medium',
    explanation: 'سەفا و مەروە دوو گیرفانن کە سەعی لە نێوانیاندا دەکرێت.'
  },
  {
    id: 118,
    question: 'کام مانگ مانگی خوداپەرستییە؟',
    options: ['مانگی محەڕەم', 'مانگی ڕەجەب', 'مانگی ڕەمەزان', 'هەموویان'],
    correctAnswer: 2,
    category: 'general',
    difficulty: 'easy',
    explanation: 'مانگی ڕەمەزان مانگی ڕۆژووگرتن و خوداپەرستییە.'
  },
  {
    id: 119,
    question: 'شەوی قەدر لە کام شەوانی ڕەمەزاندایە؟',
    options: ['شەوی ١٥ەم', 'شەوی ٢٣ەم', 'شەوی ٢٧ەم', 'دەو شەوانی دەیەی کۆتایی'],
    correctAnswer: 3,
    category: 'general',
    difficulty: 'medium',
    explanation: 'شەوی قەدر لە دەو شەوانی دەیەی کۆتایی ڕەمەزاندایە.'
  },
  {
    id: 120,
    question: 'کام ڕۆژ ڕۆژی باشترینە لە هەفتەیەکدا؟',
    options: ['یەکشەممە', 'دووشەممە', 'ئینە', 'شەممە'],
    correctAnswer: 2,
    category: 'general',
    difficulty: 'easy',
    explanation: 'ڕۆژی ئینە باشترین ڕۆژی هەفتەیە.'
  },
  {
    id: 121,
    question: 'کام شار بە "حەرەم" ناسراوە؟',
    options: ['مەککە و مەدینە', 'قودس', 'دیمەشق', 'بەغداد'],
    correctAnswer: 0,
    category: 'general',
    difficulty: 'easy',
    explanation: 'مەککە و مەدینە بە "حەرەم" ناسراون.'
  },
  {
    id: 122,
    question: 'کام مزگەوت یەکەم قیبلەی موسڵمانان بوو؟',
    options: ['مزگەوتی حەرام', 'مزگەوتی نەبەوی', 'مزگەوتی ئەقسا', 'مزگەوتی قوبا'],
    correctAnswer: 2,
    category: 'general',
    difficulty: 'easy',
    explanation: 'مزگەوتی ئەقسا یەکەم قیبلەی موسڵمانان بوو.'
  },
  {
    id: 123,
    question: 'نوێژکردن لە مزگەوتی حەرام بەرامبەری چەند نوێژە؟',
    options: ['١٠٠ نوێژ', '٥٠٠ نوێژ', '١٠٠٠ نوێژ', '١٠٠٠٠٠ نوێژ'],
    correctAnswer: 3,
    category: 'general',
    difficulty: 'hard',
    explanation: 'نوێژکردن لە مزگەوتی حەرام بەرامبەری ١٠٠,٠٠٠ نوێژە.'
  },
  {
    id: 124,
    question: 'نوێژکردن لە مزگەوتی نەبەوی بەرامبەری چەند نوێژە؟',
    options: ['١٠٠ نوێژ', '٥٠٠ نوێژ', '١٠٠٠ نوێژ', '١٠٠٠٠ نوێژ'],
    correctAnswer: 2,
    category: 'general',
    difficulty: 'hard',
    explanation: 'نوێژکردن لە مزگەوتی نەبەوی بەرامبەری ١٠٠٠ نوێژە.'
  },
  {
    id: 125,
    question: 'کام شەڕ "یەومول فورقان" ناونراوە؟',
    options: ['شەڕی بەدر', 'شەڕی ئوحود', 'شەڕی خەندەق', 'شەڕی حونەین'],
    correctAnswer: 0,
    category: 'general',
    difficulty: 'hard',
    explanation: 'شەڕی بەدر بە "یەومول فورقان" (ڕۆژی جیاکردنەوە) ناونراوە.'
  }
]

export const getQuestionsByCategory = (category: string): QuizQuestion[] => {
  if (category === 'all') return quizQuestions
  return quizQuestions.filter(q => q.category === category)
}

export const getQuestionsByDifficulty = (difficulty: string): QuizQuestion[] => {
  if (difficulty === 'all') return quizQuestions
  return quizQuestions.filter(q => q.difficulty === difficulty)
}
